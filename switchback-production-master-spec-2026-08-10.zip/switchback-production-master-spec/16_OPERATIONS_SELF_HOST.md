# Operations and Self-Hosting

## Goal

```bash
git clone ...
cp .env.example .env
docker compose up -d
```

Then setup wizard.

## Services

- `caddy`
- `web`
- `worker`
- `graphhopper`
- optional `valhalla`

No Redis required initially.
No Kubernetes.

## Default owner territory

Pennsylvania + New Jersey.

## Setup wizard

1. admin/passkey
2. storage paths
3. home region
4. optional providers
5. download source data
6. build graph
7. build initial RIG
8. run golden route smoke
9. activate

## Graph update

Build staging graph, never in-place.

```text
download source
merge
build staging
golden test
health check
stop old / switch
start new
verify
retain old for rollback
```

## Backups

Nightly:
- SQLite snapshot/backup
- route artifact manifest
- sync object metadata/data
- RIG evidence
- configuration export (secrets handled separately)

Retention:
- daily 7
- weekly 4
initial recommendation

## Observability

Health:
- web
- DB
- worker
- GraphHopper
- active graph version
- active RIG build
- pack manifest build
- optional provider status

Metrics:
- route request count
- route latency
- candidate count
- Free Ride suggestion/accept/ignore
- worker queue
- memory
- provider spend estimate
- pack failures

Privacy:
metrics must not require exact route geometry.

## Rollback

Maintain:
- previous app image
- previous DB backup
- previous router graph
- previous manifest

One documented command sequence to roll back.
