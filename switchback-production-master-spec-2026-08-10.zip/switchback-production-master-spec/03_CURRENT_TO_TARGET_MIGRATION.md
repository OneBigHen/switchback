# Current Repository → Target Architecture

This is the migration map that prevents Luna from creating parallel systems.

## `src/components/planner/PlannerShell.tsx`
Current role: broad orchestration across planning, Free Ride, recording, offline, settings, map state.

Target:
- `AppShell` owns high-level mode only.
- `PlanningSessionController` owns planning lifecycle.
- `RideSessionController` owns navigation.
- `FreeRideSessionController` owns Free Ride.
- `OfflineDataController` owns packs.
- `ImportSessionController` owns GPX ingestion/join.
- React components subscribe to narrow view models.

End state: old `PlannerShell` deleted.

## `src/components/planner/PlannerDeck.tsx`
Current role: destination, loop, profiles, voice, locks, offline, research, editing.

Target:
- Explore search sheet
- Plan candidate sheet
- Customize sheet
- Edit mode
- no permanent mega-panel

End state: old `PlannerDeck` deleted.

## `src/components/planner/RideHud.tsx`
Keep:
- navigation controller behavior worth preserving
- maneuver logic
- uncertainty/off-route concepts
- voice toggles where appropriate

Rewrite:
- visual hierarchy
- portrait/landscape layouts
- control clutter
- Free Ride slot
- mounted-phone ergonomics

## `src/lib/recommendation/free-ride.ts`
Keep/refine:
- GPS confidence gate
- workload suppression
- heading/direction rules
- expiry
- cooldown mechanics
- traversal validation

Replace:
- candidate source
- low-level ranking terms
- 30-second user-visible frequency assumptions

## `src/lib/recommendation/route-score.ts`
Replace with:
1. eligibility
2. evidence confidence
3. route utility
4. diversity selection
5. explanation

Do not keep the old score active as a hidden second ranker.

## `src/lib/domain/contracts.ts`
Use as migration seed.
Move toward clearer namespaces:
- routing
- road evidence
- navigation
- community
- offline
- identity

Runtime validation is mandatory.

## `src/lib/offline/v2-router.ts`
Keep algorithmic learning and tests.
Move execution to Geo Worker.
Replace whole-state in-memory merge with partitioned/lazy graph loading.

## `public/sw.js`
Keep bounded-cache philosophy.
Add navigation-aware update deferral.
Do not move graph ownership into service worker.

## Existing GPX
Keep existing parser/export tests as compatibility fixtures.
Introduce immutable route revision + artifact model.

## Existing local storage
Migrate in-place.
Do not discard the user's local routes/preferences.
Every IndexedDB schema change gets fixture-based migration tests.

## Existing road locks
Keep as expert control.
Use canonical road segment requirements where possible.

## Existing Spotify integration
Delete from default route/planner/ride bundle.
Retain only an isolated `MediaAccessoryProvider` seam after proving it adds negligible complexity.
