# Version / Provider Checklist Before Each Release

Re-verify:
- Node required version matches README/package/CI/container
- Next/React
- MapLibre
- Dexie
- Playwright/WebKit
- GraphHopper version/profile semantics
- Valhalla if enabled
- OSM source timestamp
- MVUM timestamp
- Google Places pricing/quota if enabled
- AI model/pricing if enabled
- OpenFreeMap usage terms
- browser storage behavior on target iOS

No release may rely on a stale pricing/free-tier assumption.
