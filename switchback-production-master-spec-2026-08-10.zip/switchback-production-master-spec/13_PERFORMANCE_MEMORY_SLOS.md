# Performance, Memory, and SLOs

## P0 requirement

The reported memory hog must be measured before refactoring claims success.

## Browser budgets

Initial release budgets:

Explore settled:
- JS heap target <100 MB where measurable

Plan with 3 candidates:
- <160 MB target

Ride:
- <140 MB target
- 2-hour simulation plateaus

Route UI-owned geometry:
- ≤10 MB excluding MapLibre internals

Geo Worker:
- 64 MB low-memory profile
- 128 MB normal mobile
- 256 MB desktop
initial graph/RIG cache caps

GPS live buffer:
- ≤2,000 points before chunk flush

## Cycle acceptance

After 10:
`plan → edit → cancel/clear`

Settled heap should be no more than:
`cold stabilized baseline +20%`

After 50 reroutes:
- old route generations reclaimed
- MapLibre source/layer count stable
- no growth in active geolocation watches/listeners

## Latency targets

Warm simple online route:
- p95 ≤2.5 s target

Offline reroute inside installed pack:
- p95 ≤2 s target

UI feedback:
- progress visible within 150 ms

No sustained main-thread long task:
- >100 ms during active Ride

## Server SLOs

Web/API:
- p95 health <250 ms
- route orchestration overhead excluding router <250 ms

GraphHopper:
- explicit JVM heap
- import/build runs isolated from serving graph

Worker:
- one large region build per configured concurrency
- queue depth visible

## Diagnostics

Expose:
- route entity count
- route geometry byte estimate
- MapLibre sources/layers
- timer count
- GPS watches
- Web Workers
- Geo Worker loaded tiles/bytes
- IndexedDB usage
- Cache Storage usage
- server RSS/heap
- GraphHopper health
- pack versions
- provider request counts/cost estimate

## Performance invariant

No optimization is accepted without:
- before
- after
- scenario
- measurement
- test or diagnostic regression protection
