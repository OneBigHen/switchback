# Road Intelligence Graph — Definitive Specification

## Purpose

Learn reusable, inspectable knowledge from vetted GPX routes at the **road-segment level**.

RIG is not:
- a route file library
- a vector embedding index for topology
- a safety database
- a legal authority
- a popularity counter

It is an evidence overlay on a canonical road graph.

## Canonical segment identity

Use OSM identity where possible:

```text
segment_uid =
SHA256(
  osm_way_id |
  from_osm_node_id |
  to_osm_node_id |
  direction
)
```

GraphHopper/Valhalla internal edge IDs are ephemeral and must not be persisted as canonical identity.

Store:
- `segment_uid`
- OSM snapshot/build
- way id
- endpoint node ids
- direction
- geometry hash
- geometry
- length
- topology version

## OSM change handling

Migration order:
1. exact way + endpoints
2. same way + directional geometry overlap
3. spatial/directional overlap
4. one-to-many or many-to-one lineage record
5. ambiguous evidence quarantined

Never guess a migration because "the road is nearby."

### Lineage table

```text
old_segment_uid
new_segment_uid
overlap_ratio
direction_match
migration_confidence
source_build
target_build
```

## Evidence source classes

Suggested v1 priors:

| Source | Weight |
|---|---:|
| device-recorded human ride | 1.00 |
| creator explicitly says ridden/verified by them | 0.75 |
| curated/planned route | 0.45 |
| imported unknown-provenance GPX | 0.20 |
| Switchback-generated route | 0.00 |

These are engineering priors and must be calibrated.

## GPX deduplication

### Exact duplicate
Hash canonical normalized points/artifact.

### Near duplicate
After map matching, compute:
- ordered canonical segment list
- shared directed segment length
- sequence edit similarity
- start/end proximity
- route length ratio

Near-duplicate family when:
- shared weighted segment length ≥ configurable threshold (initial candidate: 85%)
- direction largely matches
- total distance ratio is close
- no material distinct branch

### Independence

Do not count copied GPX variants as independent evidence.

```text
duplicate_independence =
1 / sqrt(1 + duplicate_family_count_for_contributor_group)
```

Contributor independence for a small community should be conservative:
- one identity can contribute at most a bounded positive amount per segment
- identical/near-identical route families saturate
- independent identities are still not assumed independent if source artifact is clearly copied

## Evidence weight

For observation `i` on segment `e`:

```text
w_i =
source_weight
* map_match_confidence
* covered_fraction
* freshness
* duplicate_independence
* identity_cap
* route_role_weight
```

Freshness:

```text
freshness = exp(-ln(2) * age_days / half_life_days)
```

Suggested:
- preference evidence half-life: 2–4 years
- closure/problem report half-life: much shorter unless reconfirmed
- official source governed by dataset timestamp, not generic decay

## Route-role inference

A major failure mode is promoting boring connector roads merely because they appear in good GPX routes.

Classify each contiguous run:
- `highlight`
- `supporting`
- `connector`
- `unknown`

Signals:
- intrinsic recreational interest
- contiguous length
- direct-baseline comparison
- local alternative availability
- repeated independent selection despite faster parallel path
- surface / curvature / elevation
- route notes
- whether run is simply approach/egress in many routes

Example route role model:

```text
role_score =
  0.30 intrinsic_interest
+ 0.25 independent_repeat_selection
+ 0.20 contiguous_length_quality
+ 0.15 deviation_from_fast_connector
+ 0.10 explicit_positive_notes
```

Then:
- highlight ≥ 0.70
- supporting 0.45–0.70
- connector ≤ 0.30
- middle/low-confidence = unknown

Do not hard-code without golden-corpus calibration.

## Confidence versus desirability

They are distinct.

A road can be:
- desirable with low confidence
- undesirable with high confidence
- highly desirable and high confidence
- unknown

### Evidence strength

```text
W = sum(max(w_i, 0))
confidence = 1 - exp(-W / kappa)

independent_diversity =
1 - exp(-independent_source_count / delta)

evidence_strength =
confidence * (0.5 + 0.5 * independent_diversity)
```

## Preference posterior

Explicit positive/negative rider feedback:

```text
alpha = alpha0 + Σ positive_weight
beta  = beta0  + Σ negative_weight
preference_mean = alpha / (alpha + beta)
```

Use a weak prior such as alpha0=beta0=1.

**Absence is not negative evidence.**

## Negative/access evidence

Different classes:

### Hard authority
- active official closure
- explicit current legal restriction
- motorcycle forbidden
- applicable seasonal closure

These influence eligibility.

### Soft current report
- gate reported closed
- washout
- bridge out
- severe roughness
- private-sign report

These create warnings or temporary penalties based on source/repetition/recency.

### Preference negative
- less-like-this
- rider explicitly marks boring/rough

These affect desirability only.

Never blend all negatives into one "bad road" number.

## Segment dimensions

Persist normalized dimensions, not one score:

- twisty_interest
- gravel_interest
- dirt_interest
- scenic_proxy
- elevation_interest
- remoteness
- flow
- paved_touring_interest
- technicality_estimate
- community_interest
- familiarity
- novelty
- evidence_confidence
- access_confidence
- surface_confidence

## Curvature

Resample road geometry at fixed spatial interval.
Suppress:
- intersection turns
- tiny geometry noise
- parking/service-road jitter

```text
curvature_density =
Σ(min(abs(delta_heading), heading_cap) * continuity_factor)
/
length_km
```

Transform with a saturating logistic function.

## Contiguous corridor intelligence

The meaningful object for route generation is often a **corridor cluster**, not a point.

A corridor:
- connected/near-connected high-value segments
- minimum useful contiguous length
- coherent surface/ride character
- entry/exit nodes
- expected utility
- confidence
- provenance

Ten disconnected 0.2-mile gravel snippets must not beat a 12-mile coherent gravel run.

## RIG build outputs

Server:
- canonical segment DB
- evidence events
- aggregate tables
- spatial index
- corridor cluster table

Offline:
- compact RIG tile slice
- only dimensions required for installed profiles
- provenance timestamps
- no private user evidence unless intentionally included in private local pack
