# PWA-First Decision and Native Trigger

## Current decision

PWA first remains correct because:
- current app is already web/PWA
- one codebase is ideal for owner + small self-host community
- offline storage/service worker/MapLibre are viable
- install friction is low
- native rewrite would delay routing quality and Free Ride

## But PWA is conditional

Navigation credibility matters more than architectural purity.

A thin native wrapper becomes mandatory if field testing proves any **release-blocking** platform limitation.

## Native trigger criteria

Build a thin native shell if, on target iPhone hardware, any of these remain unresolved after PWA tuning:

1. Reliable navigation GPS cannot continue for required use when screen/app state changes.
2. Voice guidance cannot reliably continue under realistic background/media conditions.
3. Wake-lock / screen behavior makes multi-hour mounted navigation unreliable.
4. iOS terminates or suspends the PWA frequently enough to break ride continuity.
5. Offline pack storage is evicted/unavailable at unacceptable rates despite persistence strategy.
6. Bluetooth/media/navigation coexistence is materially worse than expected.
7. Battery use is >1.5× a reference navigation app primarily due to browser platform overhead that cannot be optimized.
8. Required native capabilities such as CarPlay become a product goal.

## Thin wrapper principle

Do not rewrite business logic in Swift/Kotlin.

Native shell should provide only:
- background location bridge
- audio session
- wake behavior
- file share/import
- optional CarPlay later
- local filesystem bridge
- WebView/PWA hosting where appropriate

Routing/RIG/domain contracts remain shared.

## Field decision gate

P35 produces `NATIVE_DECISION.md`:
- PWA passes
- thin wrapper required
- feature-specific wrapper optional

No assumption before measurement.
