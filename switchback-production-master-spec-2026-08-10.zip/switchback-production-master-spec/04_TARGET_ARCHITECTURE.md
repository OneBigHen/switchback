# Target Architecture

```mermaid
flowchart LR
  Rider --> PWA

  subgraph Browser
    PWA[AppShell: Explore / Plan / Ride / Library]
    MAP[Persistent MapLibre]
    GEO[Geo Worker]
    IO[IO Worker]
    SW[Service Worker]
    IDB[(Dexie / IndexedDB)]
  end

  subgraph LXC
    WEB[Next.js web/API]
    WORKER[Background worker]
    GH[GraphHopper]
    VAL[Valhalla optional]
    DB[(SQLite WAL)]
    DATA[(GPX / region artifact store)]
  end

  PWA --> MAP
  PWA <--> GEO
  PWA <--> IO
  PWA <--> IDB
  SW --> PWA
  PWA <--> WEB
  WEB <--> GH
  WEB -. optional .-> VAL
  WEB <--> DB
  WORKER <--> DB
  WORKER <--> DATA
  WORKER <--> GH
```

## Browser responsibilities

Main thread:
- React/UI
- map camera
- route summaries
- current navigation view model
- interaction

Geo Worker:
- offline graph
- offline RIG
- snap/map match for local graph
- local reroute
- Free Ride local candidate evaluation
- route corridor computations

IO Worker:
- GPX parse/serialize
- hashing
- pack decompression/validation
- large binary conversion

Service Worker:
- app shell
- build asset caching
- update lifecycle
- online/offline request interception where appropriate

Do not create separate graph workers per feature.

## Server responsibilities

`web`:
- authenticated/public API
- lightweight orchestration
- provider proxy
- validation
- request ids
- no bulk graph jobs

`worker`:
- GPX ingest
- map-match corpus
- RIG evidence aggregation
- AI route-description jobs
- region manifests
- pack builds
- migrations needing batch processing

`graphhopper`:
- legal connected routing
- map matching where used
- alternatives
- custom model semantics

`valhalla`:
- optional only
- benchmark map matching / alternative behavior
- never mandatory for healthy baseline deployment

## Data ownership invariant

Each large payload has one owner.

- MapLibre owns rendered map tiles.
- route entity cache owns active full online route geometry.
- Geo Worker owns decompressed offline graph tiles.
- IO Worker owns GPX parse buffers while active.
- worker service owns corpus/batch geometry.
- UI stores references/summaries.

No giant GeoJSON object appears in React state, Zustand, IndexedDB live object, and MapLibre source simultaneously.

## Request cancellation

Every async route/search/match request has:
- request id
- generation id
- AbortController
- stale-response gate

A stale result must never mutate current route selection.
