# Switchback — Long-Running Agent Goal

Build Switchback into a production, self-hostable, mobile-first ADV / dual-sport PWA. **Do not rebuild from scratch.** Preserve the working foundation; simplify the product, remove dead complexity, fix memory/state ownership, and replace weak routing intelligence with evidence-backed systems.

Switchback should feel like **Google Maps for riders who care about the road more than the destination**.

Core flow: **Explore → Plan → Ride → Learn → Save/Share**

Primary actions:
- **Where to?** — destination routing that prefers enjoyable roads.
- **Make a Loop** — ride around time/distance.
- **Just Ride** — no destination; suggest worthwhile roads ahead.
- **Import GPX** — analyze, join, navigate, modify, save, and export.

The map owns the screen. Advanced controls belong behind **Customize / Edit / Explorer Mode**.

## Intelligence

Turn vetted GPXs into a **Road Intelligence Graph (RIG)**. Map-match them onto canonical OSM road segments and store provenance, access/surface, curvature, elevation, MVUM evidence, route role, confidence, independent-source support,. Duplicate/copied GPXs must not inflate evidence. Boring connectors must not become “great roads” because they appear inside good routes. Switchback-generated routes contribute **zero** RIG evidence.

**GraphHopper remains authoritative for legal/topological routing.** AI may interpret free text, describe/compare routes, summarize notes,, but must never invent legality, surface, safety, or route geometry.

Routing pipeline:

**intent → hard constraints → candidates → legal routing → features → eligibility → utility → diversity → explanation**

Hard legality/access/closure/bike constraints execute before scoring. Return genuinely different routes with measurable explanations.

## Free Ride

Free Ride is first-class. Use location, heading, speed, GPS confidence, bike policy, RIG corridors, and reachable decision points. Suggest only legal, forward, useful opportunities with real detour/rejoin calculations. Silence is valid. Target ~1–3 unsolicited suggestions/hour. Accepted suggestions must actually traverse the intended corridor or fail honestly.

## Architecture

Heavy work runs on the faster LXC.

Server: web/API, worker, GraphHopper, optional Valhalla, SQLite WAL, artifact/region storage.

Browser: one persistent MapLibre map; one **Geo Worker** for offline graph/RIG/snap/reroute/Free Ride; one **IO Worker** for GPX/pack work; Dexie/IndexedDB; service worker for app-shell/update lifecycle.

UI stores ids/summaries, not duplicate full GeoJSON. All listeners, timers, GPS watches, workers, sources/layers, requests, and caches must be bounded and cleaned up.

## GPX / Offline / Community

GPX supports matched and unmatched track-only spans. “Join & Ride” is one continuous **Approach → GPX → Finish** session; reaching the GPX start is not final arrival.

Offline uses **Region Packs** and smaller **Ride Packs** with hashes, atomic install, rollback, and routing territories. Never load an entire state graph as main-thread JS objects.

Core use requires no account. Publishing/comments use optional pseudonymous passkey identity. Private sync is optional and client-side encrypted. No social-feed/forum scope.

## Execution

Execute `roadmap/phases/P01.md` through `P36.md` **in order**. Read linked specs before each phase.

Never add fake routing evidence, weaken tests, duplicate global state, hide failures behind fake success, make AI authoritative for routing, wipe user data, or leave old/new systems active indefinitely.

Every phase ends with tests/builds, relevant router/PWA/performance evidence, deletion of superseded code, migrations, and the required phase report.

**Final goal:** ship a simple, trustworthy, fast, offline-capable riding product that consistently finds better roads and can be relied on during a real ride.
