# Offline, Region Packs, and Server Territories

## User-facing model

### Region Pack
For spontaneous riding in a broad area.

### Ride Pack
For one selected ride and nearby recovery.

## Capability matrix

Each pack explicitly advertises:

- map
- selected route
- voice/maneuvers
- local reroute
- local search
- POIs
- elevation
- RIG
- MVUM
- weather (normally online-only)
- live closures (normally online-only)

UI says exactly what is ready.

## State selection

User can choose:
- Pennsylvania
- New Jersey
- New York
etc.

Internally:
- packs are chunked
- border halo included
- routing territory may span multiple selected states
- do not pretend state line = graph line

## Server GraphHopper territory

Recommended:
1. download selected adjacent state PBFs
2. merge
3. normalize/extract
4. build staging GraphHopper graph
5. run golden routes
6. health check
7. atomically switch active graph
8. keep prior graph for rollback

Distant states can form separate territories.

Do not attempt one huge USA graph by default.

## Browser graph

One Geo Worker.

Graph tiles:
- binary arrays
- content addressed
- lazy loaded
- spatially indexed
- byte-bounded LRU
- cancellation-aware

Never merge full Pennsylvania into millions of JS objects on main thread.

## Suggested binary structure

```text
nodes:
  latE7 Int32[]
  lonE7 Int32[]
  firstEdge Uint32[]

edges:
  toNode Uint32[]
  nextEdge Uint32[]
  distanceDm Uint32[]
  baseCost Uint32[]
  flags Uint32[]
  segmentRef Uint32[]

geometry:
  delta encoded coordinate stream

restrictions:
  compact turn restriction arrays
```

## Partition selection

Benchmark:
- H3
- S2
- quadkey
- current custom tile
- graph partition

Requirements:
- bounded decompression
- few border edges
- corridor-friendly
- stable content addressing
- fast snap

Do not choose based on fashion.

## Ride Pack corridor

Includes:
- route
- alternatives
- approach/egress
- reroute graph buffer
- map tiles
- RIG slice
- critical POIs
- elevation

Initial corridor width is a benchmark parameter, not fixed policy.

## Manifest

See `contracts/pack-manifest.schema.json`.

## Install transaction

```text
download temp
→ hash verify
→ schema validate
→ index validate
→ capability validate
→ write ready marker
→ atomic activate
→ clean old version later
```

Interrupted or corrupt update leaves old good version intact.

## Storage

Before install:
- `navigator.storage.estimate()`
- request persistence when appropriate
- show estimated size
- reserve margin
- offer stale Ride Pack cleanup

Never auto-delete:
- user GPX
- saved route
- recorded ride
without explicit policy/consent.

## Service worker

Does not own graph.

Update activation is deferred while Ride mode is active.
