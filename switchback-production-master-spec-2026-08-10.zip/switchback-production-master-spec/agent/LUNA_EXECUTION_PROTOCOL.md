# Luna Execution Protocol

The implementation model is expected to take shortcuts unless the phase contract prevents it.

## Before every phase

1. Read the entire phase file.
2. Read all linked definitive specs.
3. Inspect current repository implementation.
4. Inspect current tests.
5. Write a short "Before" section in `WORKLOG.md`.
6. Record baseline if phase concerns performance/routing.

## During

Never:
- create placeholder fake route data
- hard-code scenic/access/confidence
- add `any` to escape design
- create a second global store
- weaken an assertion just to pass CI
- swallow an exception and return success
- mark offline capability that is not truly present
- use AI-produced geometry as routing truth
- duplicate route geometry
- make generated routes reinforce RIG
- make a public route from private local data without explicit publish action
- expose GraphHopper publicly

## After

Mandatory:
- lint
- typecheck
- target unit tests
- full unit
- relevant Playwright
- build
- real-router suite for routing phases
- PWA suite for storage/service-worker phases
- memory/benchmark evidence where required
- update docs/migrations
- remove superseded path
- phase report

## Phase report

```text
Phase:
Current SHA:
Before behavior:
After behavior:
Files changed:
Files deleted:
Migrations:
Tests:
Commands:
Results:
Memory/performance evidence:
Routing quality evidence:
Known limitations:
Deferred:
Rollback:
Next dependency:
```

## Stop conditions

Stop the phase instead of improvising if:
- required schema conflicts with real persisted data
- provider behavior is materially different from spec
- phase would require >30% unrelated scope expansion
- security protocol would require home-grown crypto
- real router semantics invalidate the proposed design

Document and escalate.
