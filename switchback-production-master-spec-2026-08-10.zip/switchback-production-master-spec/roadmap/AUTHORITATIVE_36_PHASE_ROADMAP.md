# Authoritative 36-Phase Roadmap

Do not skip phases because later UI work is more visible.

| Phase | Name | Goal | Gate |
|---:|---|---|---|
| P01 | Baseline & provenance | Freeze current repo, source/provider versions, screenshots, route fixtures, dependency/runtime contract | G1 |
| P02 | Memory observability | Instrument browser/LXC/router/store/map/worker memory and establish reproducible soaks | G1 |
| P03 | Dead complexity removal | Cut Spotify core, dead modules, duplicate controls, unsupported claims | G1 |
| P04 | Error/health/provenance | Request ids, failure taxonomy, provider degradation, route provenance | G1 |
| P05 | AppShell modes | Explore/Plan/Ride/Library shell with persistent map | G2 |
| P06 | Planning controller | Remove planning orchestration from React god component | G2 |
| P07 | Canonical route cache | One owner for large geometry; summaries/ids in UI stores | G2 |
| P08 | Worker RPC + leak cleanup | Typed cancelable RPC, listener/timer/source lifecycle | G2 |
| P09 | Canonical segment graph | Stable OSM-directed segment identity + migration lineage | G3 |
| P10 | GPX ingest worker | Stream/normalize/map-match owner's corpus; exact/near duplicate families | G3 |
| P11 | Intrinsic road features | Surface/access/curvature/elevation/flow/MVUM provenance | G3 |
| P12 | RIG evidence aggregation | Route-role, bounded contributor evidence, confidence/desirability separation | G3 |
| P13 | RIG corridor clustering | Contiguous high-value corridors + spatial tile/index build | G3 |
| P14 | Eligibility engine | Hard legality/closure/bike/surface/coverage gates before utility | G3 |
| P15 | Route utility v2 | Contiguous quality, detour, overlap, uncertainty, personalization | G3 |
| P16 | Candidate generator | Direct/native/RIG/loop/community candidates with bounded search | G3 |
| P17 | Diversity + explanations | MMR segment overlap; human-readable facts | G3 |
| P18 | PA/NJ golden tuning | Owner-reviewed regression corpus and versioned policy freeze | G3 |
| P19 | Design system | Map-first responsive primitives, bottom sheet, typography/touch rules | G4 |
| P20 | Explore/search | Simple home + free text/destination/loop/GPX | G4 |
| P21 | Plan result UX | 2–3 meaningful route alternatives and explanations | G4 |
| P22 | Expert Customize/Edit | Surface/bike/locks/sketch/avoid/vias behind progressive disclosure | G4 |
| P23 | Ride HUD v2 | Portrait/landscape mounted-phone interface | G5 |
| P24 | Navigation state machine | GPS filtering, off-route, forward rejoin, resume, voice/wake | G5 |
| P25 | Free Ride graph engine | Ahead/reachable RIG candidate generation + real detour/rejoin | G5 |
| P26 | Free Ride interruption/learning | Sparse prompts, quiet periods, preference updates, Head Home | G5 |
| P27 | GPX intelligence | Analysis, confidence, unmatched spans, grounded description | G6 |
| P28 | GPX join/export | Approach→GPX continuous navigation + generic/export profiles | G6 |
| P29 | Offline Geo Worker | Partitioned binary graph/RIG, lazy tiles, byte LRU, local reroute | G6 |
| P30 | Region/Ride Packs | Manifests, state selector, territory builds, atomic install/update | G6 |
| P31 | Community backend | Anonymous browse, route revisions/artifacts/comments/reports, RIG contribution | G7 |
| P32 | Passkey identity/privacy | Pseudonymous writes, privacy-zone publish preview | G7 |
| P33 | Encrypted sync | Opaque client-encrypted objects, backup/recovery, conflict behavior | G7 |
| P34 | Grounded AI layer | Strict intent schema, route descriptions, spatial-first semantic search | G7 |
| P35 | Security/ops/field beta | Hardening, Docker, backups, chaos, battery/thermal, external riders, native decision | G8 |
| P36 | Production release | Migration, policy/data version freeze, runbook, rollback, tagged release | G8 |
