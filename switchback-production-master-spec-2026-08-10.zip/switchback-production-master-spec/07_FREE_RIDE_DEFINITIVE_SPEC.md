# Free Ride — Definitive Specification

## Promise

Tap **Just Ride** and start riding.

Free Ride does not force a destination and does not constantly interrupt.

Silence is a successful output.

## States

```text
IDLE
ARMING
ACTIVE_QUIET
EVALUATING
SUGGESTION_READY
SUGGESTION_VISIBLE
ACCEPTED_BUILDING
GUIDED_DETOUR
RETURNING_TO_FREE_RIDE
COOLDOWN
PAUSED
ENDED
```

All transitions are explicit and unit tested.

## Rolling context

Keep bounded:
- last 60–90 sec filtered GPS
- current matched segment
- heading
- speed
- GPS accuracy/confidence
- recent segment ids
- recent suggestions
- bike/ride intent
- optional time budget
- optional home destination for Head Home
- current offline capability
- weather/closures snapshot if online

Do not store an unbounded ride in React state.

## Evaluation cadence

Candidate computation can run often, e.g. every 15–30 seconds when moving, but **user-facing suggestions are sparse**.

Normal interruption policy:
- target 1–3 unsolicited suggestions/hour
- hard minimum ~5 minutes after a shown suggestion
- after two ignores: 20-minute quiet period
- user can tap `More ideas` to bypass quiet evaluation
- exceptional opportunity can exceed normal threshold once, with bounded override rules

## Reachable forward horizon

Horizon is network-based and speed-sensitive.

Starting tuning:

| Speed | Graph horizon |
|---|---|
| <25 mph | 3–6 mi |
| 25–45 | 5–10 mi |
| 45–65 | 8–16 mi |
| >65 | 12–22 mi |

These are tunable.

## Candidate classes

- interesting branch
- better continuation
- gravel opportunity
- scenic/terrain opportunity
- community corridor
- mini-loop
- stop/fuel only if relevant
- head-home corridor

## Candidate generation

1. map-match current position
2. compute forward reachable decision nodes
3. discard behind/poor-direction branches
4. query RIG corridors near reachable nodes
5. generate legal detour/rejoin path
6. compute true added time/distance
7. apply eligibility
8. score marginal gain
9. apply interruption cost
10. emit zero or one suggestion

## Marginal Free Ride value

```text
gain =
utility(detour_or_branch)
- utility(continue_baseline)

user_value =
gain
- a * added_time
- b * uncertainty
- c * prompt_recency
- d * maneuver_complexity
- e * similarity_to_recent_suggestions
```

Suggest only if value > threshold.

## Directionality

Use graph path direction and current matched heading.

Do not rely only on straight-line bearing.

Default:
- prefer ±70° ahead
- exploratory mode can widen
- no surprise U-turn candidate

## Rejoin design

A Free Ride suggestion should preferably:
- branch
- traverse worthwhile corridor
- rejoin generally forward

If it does not rejoin, it must have an obvious onward reason.

## Accept

Accepted suggestion becomes a temporary required corridor:
- route through entry/exit anchors
- validate resulting geometry covers intended corridor
- target ≥80% meaningful corridor traversal where possible
- if router cannot honor, state failure

Never claim success because a route merely touched one point.

## Ride HUD suggestion

Collapsed:

`Great gravel ahead · +12 min`

Expanded:
- title
- decision distance
- added time
- expected unpaved distance
- why it is interesting
- confidence/source
- Take it
- Skip
- Less like this

## Voice

Very brief:
> "Good gravel road ahead in one mile. Adds about twelve minutes."

Do not read a paragraph.

## Workload gate

Suppress when:
- maneuver imminent
- complex junction
- high GPS uncertainty
- high speed + short decision distance
- active safety/weather alert
- route recovery/reroute underway
- two recent ignored suggestions
- screen/app platform state makes cue unreliable

## Offline

If graph + RIG installed:
- candidate generation works locally
- live weather/closure/community updates unavailable
- UI shows data timestamp
- capabilities requiring missing data are suppressed

## Acceptance

Free Ride cannot leave Experimental until:
- no synthetic road attributes
- every candidate has provenance
- behind-rider fixtures = 0 suggestions
- accepted corridor traversal verified
- 60-min simulation respects frequency budget
- 2-hour memory soak plateaus
- offline simulation works
- no candidate violates hard access/closure rules
