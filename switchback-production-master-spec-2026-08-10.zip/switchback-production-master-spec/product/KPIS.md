# KPIs

## Reliability
- error-free ride sessions >99.5%
- valid route start success >99%
- fatal navigation state errors = 0 in release corpus

## Route quality
- hard eligibility overridden by score = 0
- near-duplicate 3-route responses <5%
- every explanation fact traceable to metric/provenance

## Free Ride
- normal unsolicited suggestions ≤3/hour
- behind-rider suggestion = 0
- accepted-but-unroutable suggestion = 0
- acceptance rate is observed, not gamified

## Performance
- 10-cycle settled heap ≤ baseline +20%
- no unbounded GPS history
- no unbounded graph/RIG cache
- map instances = 1 normal Explore/Plan lifecycle

## Community
Track:
- route downloads
- routes remixed
- independent vetted road coverage
- useful notes
not:
- engagement time
- follower counts
