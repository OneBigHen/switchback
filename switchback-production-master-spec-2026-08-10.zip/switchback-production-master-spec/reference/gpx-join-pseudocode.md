# GPX Join Pseudocode

```text
inputs:
  current_location
  matched_gpx_sequence
  route_semantics
  rider_policy

candidates = [
  original_start,
  forward_nearby_points,
  semantic_waypoints,
  leg_boundaries
]

for candidate in candidates:
  approach = router.route(current_location, candidate)
  if !approach:
    reject

  backwards = directionPenalty(candidate)
  skipped = semanticSkipPenalty(candidate)
  remaining = usefulRemainingRoute(candidate)

  score =
    - approach.time
    - backwards
    - skipped
    + remaining
    + riderPreference(candidate)

return top:
  Best Join
  Original Start
  user manual option

navigation session:
  APPROACH -> JOIN_TRANSITION -> GPX_FOLLOW -> FINISH
```

`JOIN_TRANSITION` is not arrival.
