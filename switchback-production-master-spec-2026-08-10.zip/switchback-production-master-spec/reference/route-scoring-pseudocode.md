# Route Scoring Pseudocode

```text
function rank(request):
  baseline = graphhopper.direct(request)

  rawCandidates = union(
    baseline,
    graphhopper.alternatives(request),
    rigAnchorCandidates(request),
    loopSeeds(request if loop),
    communityCorridorCandidates(request)
  )

  candidates = dedupe(rawCandidates)

  eligible = []
  for candidate in candidates:
    features = featureExtractor(candidate)
    eligibility = eligibilityEngine(features, request)
    if eligibility.blocked:
      continue

    utility = utilityEngine(features, request)
    eligible.append({
      candidate,
      features,
      utility,
      warnings: eligibility.warnings
    })

  selected = []
  while selected.length < 3 and eligible not empty:
    best = argmax(
      route.utility
      - diversityLambda * maxSimilarity(route, selected)
    )
    selected.push(best)
    eligible.remove(best)

  return selected.map(explain)
```

Invariant:
- utility never "unblocks" a forbidden route.
