# Free Ride Pseudocode

```text
tick(context):
  if !moving(context):
    return none

  if gpsConfidence < threshold:
    return none

  if workloadHigh(context):
    return none

  if quietPeriodActive(context):
    return none

  current = snap(context.location, context.heading)

  horizon = reachableForwardGraph(current, context.speed)

  decisions = candidateDecisionNodes(horizon)

  opportunities = []
  for decision in decisions:
    corridors = rig.queryNear(decision, intent)
    for corridor in corridors:
      if behindRider(corridor, context):
        continue

      detour = routeThroughCorridorAndRejoin(current, corridor, context)

      if !detour:
        continue

      if !eligible(detour):
        continue

      gain = utility(detour) - utility(localContinueBaseline)
      interruption = interruptionCost(context, corridor, detour)

      value = gain - interruption

      if value > threshold:
        opportunities.push(...)

  return highestValue(opportunities) or none
```

Never fabricate a corridor when RIG/graph evidence is absent.
