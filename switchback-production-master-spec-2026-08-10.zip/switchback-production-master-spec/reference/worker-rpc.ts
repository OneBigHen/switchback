export type RpcRequest =
  | { id: string; generation: number; type: "offline-route"; payload: OfflineRoutePayload }
  | { id: string; generation: number; type: "free-ride-evaluate"; payload: FreeRidePayload }
  | { id: string; generation: number; type: "load-pack"; payload: LoadPackPayload }
  | { id: string; generation: number; type: "evict-pack"; payload: { packId: string } };

export type RpcResponse =
  | { id: string; generation: number; ok: true; payload: unknown; transfer?: ArrayBuffer[] }
  | { id: string; generation: number; ok: false; error: { code: string; message: string } };

export interface CancelRequest {
  type: "cancel";
  id: string;
  generation: number;
}

export interface OfflineRoutePayload {
  start: [number, number];
  finish: [number, number];
  shaping?: [number, number][];
  installedPackIds: string[];
  bikePolicyId: string;
}

export interface FreeRidePayload {
  coordinate: [number, number];
  headingDegrees?: number;
  speedMps?: number;
  gpsConfidence: number;
  bikePolicyId: string;
  recentSegmentIds: string[];
}

export interface LoadPackPayload {
  packId: string;
  manifest: unknown;
}

// Implementation rules:
// 1. Every request can be cancelled.
// 2. Generation mismatch means response is stale and must be ignored.
// 3. Large buffers are transferred, not repeatedly structured-cloned.
// 4. Geo Worker owns graph/RIG LRU memory.
// 5. No direct React imports in worker/domain code.
