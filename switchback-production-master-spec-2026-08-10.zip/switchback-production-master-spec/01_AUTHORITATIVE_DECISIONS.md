# Authoritative Decisions

These decisions are binding unless an ADR explicitly supersedes them.

| Area | Decision |
|---|---|
| Product | ADV / dual-sport road-intelligence + navigation PWA |
| Primary differentiator | Graph-backed **Free Ride** |
| Knowledge model | **Road Intelligence Graph**, not RAG for topology |
| Online routing | Self-hosted GraphHopper primary |
| Alternate router | Valhalla optional/benchmark/fallback only when semantics match |
| Map renderer | MapLibre |
| Default basemap | OpenFreeMap-compatible style/provider abstraction |
| Offline graph | Binary partitioned graph in one **Geo Worker** |
| Bulk browser tasks | One **IO Worker** |
| Service worker | App shell/network lifecycle only |
| Browser large geometry | Canonical entity cache; UI stores ids/summaries |
| GPX | First-class ingest, analysis, join, navigation, export |
| AI | Intent/description/explanation only; deterministic routing remains authoritative |
| Accounts | None required for core use |
| Community writes | Optional pseudonymous passkey identity |
| Private sync | Optional client-side encrypted opaque object sync |
| Community | Route-centered; no feed/forum/DMs |
| Storage | Dexie/IndexedDB initially; bulk blob abstraction allows OPFS later |
| Server metadata DB | SQLite WAL initially |
| Region model | User selects states; implementation uses chunks + border halos/territories |
| Deployment | Existing LXC, Docker Compose, no Kubernetes/Redis required |
| Live traffic | Deferred unless evidence justifies cost |
| God Mode | Keep as lazy-loaded **Explorer Mode** |
| Spotify | Cut from core, provider seam retained |
| Native app | Defer; thin wrapper triggered only by measured PWA platform failures |
| ML ranker | Defer until enough real preference data exists |
| Safety language | Never claim "safe"/"verified/open" without exact supporting evidence |
| Generated routes as evidence | Weight = 0; a model cannot reinforce its own output |
| Negative evidence | Absence from a GPX is never negative evidence |
| Community GPX | Useful preference evidence, never legal authority |
