# Build This in Order

Use this as the single execution checklist.

## Gate G1
- P01 baseline
- P02 memory instrumentation
- P03 cut dead complexity
- P04 errors/provenance

Do not redesign UI yet.

## Gate G2
- P05 shell
- P06 controller
- P07 route cache
- P08 workers/leaks

Do not build RIG while state ownership is still duplicated.

## Gate G3
- P09 canonical road graph
- P10 GPX ingest
- P11 intrinsic features
- P12 RIG aggregation
- P13 corridors
- P14 eligibility
- P15 utility
- P16 candidates
- P17 diversity/explanations
- P18 PA/NJ tuning

At the end, route quality must be inspectable.

## Gate G4
- P19 design system
- P20 Explore
- P21 Plan
- P22 expert edit

The old planner UI must be removed, not merely hidden forever.

## Gate G5
- P23 Ride HUD
- P24 navigation
- P25 graph Free Ride
- P26 interruption/learning

## Gate G6
- P27 GPX intelligence
- P28 GPX join/export
- P29 offline Geo Worker
- P30 packs

**Private beta candidate.**

## Gate G7
- P31 community
- P32 passkeys/privacy
- P33 encrypted sync
- P34 AI

## Gate G8
- P35 security/ops/field
- P36 production

No "production" label before field/device/rollback gates.
