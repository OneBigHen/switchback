# Identity, Sync, and Community

## Three levels

### Level 0 — Local Rider
No account.
Can:
- plan
- ride
- save
- import/export
- use offline
- browse community

### Level 1 — Switchback ID
Optional pseudonymous WebAuthn/passkey identity.
Needed for:
- publish
- comment
- report ownership actions

No email/password required.

### Level 2 — Private Sync
Optional client-side encrypted object sync.

## WebAuthn

Server stores:
- credential id
- public key
- counter/metadata
- pseudonymous identity id

Never private key.

HTTPS required outside localhost.

## Private sync

Server stores opaque encrypted objects.

Use:
- random 256-bit sync root
- HKDF-SHA256 per object key derivation
- AES-256-GCM authenticated encryption
- fresh nonce per object
- authenticated metadata includes schema, namespace, collection, object id, revision

Use WebCrypto or reviewed library.
No custom primitive implementation.

## Device pairing

Preferred:
- passkey-synced identity where platform handles it

Optional QR pairing:
- one-time room
- short TTL
- ECDH ephemeral keys
- encrypted sync root transfer
- room destroyed on success/timeout

Do not ship QR pairing until reviewed and tested.

Safer fallback for v1:
- encrypted backup file / recovery kit
- passkey login
- restore sync root locally

## Recovery phrase

Do not invent a word scheme.
If implemented:
- standard reviewed encoding
- ≥256 bits entropy
- checksum
- offline display
- explicit warning

## Sync merge

Routes:
- immutable geometry revisions
- concurrent geometry edits produce conflict copies

Settings:
- per-field/object revision
- bounded LWW where safe

Deletes:
- tombstones

No full CRDT framework unless actual conflicts justify it.

## Community

Route-centered only.

Objects:
- route
- revision
- GPX artifact
- notes
- comments
- reports
- moderation action

No feed.

## Publish privacy

Before public upload:
- trim start/end around private locations
- redact instructions/street names in zone
- rebase metrics
- show exact public geometry preview
- uploader confirms provenance

## Provenance selector

- I rode/recorded this
- I built and verified it myself
- I curated/planned it
- I do not know

This changes RIG evidence weight.

## Abuse

- passkey for writes
- IP/identity rate limits
- route upload caps
- duplicate spam detection
- plain/sanitized text
- report/hide/admin audit
- no arbitrary HTML
