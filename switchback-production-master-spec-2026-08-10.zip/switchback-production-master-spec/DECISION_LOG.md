# Decision Log

## Changed after deeper research

### Use two browser application workers, not many
Earlier designs risked separate offline/free-ride/matching workers loading the same graph repeatedly.
Final: one **Geo Worker** + one **IO Worker**.

### Keep IndexedDB as first bulk store
Do not prematurely rewrite to OPFS. Hide storage behind a blob-store abstraction and benchmark OPFS later.

### PWA remains first, but not dogmatic
Production field tests now contain explicit native-wrapper trigger conditions.

### Free Ride normal frequency is lower
Internal candidate evaluation can be frequent; normal rider interruption is intentionally sparse.

### State downloads are a product abstraction
Internally packs are content-addressed chunks and border-aware territories.

### Community provenance is explicit
A GPX upload cannot automatically mean "vetted."

### Generated routes never train RIG
Prevents self-reinforcing routing feedback loops.
