# Migration Checklist

For every persistent change:

## Browser
- identify current Dexie/localStorage schema
- fixture old versions
- upgrade in transaction
- preserve unknown future-compatible fields where appropriate
- no `localStorage.clear()`
- no database deletion as migration strategy
- backup/export path for unrecoverable corruption

## Server
- numbered SQL migration
- pre-migration backup
- forward migration
- rollback or documented restore
- compatible application rollout order

## Router/RIG
- graph build id
- RIG build id
- OSM timestamp
- official dataset timestamps
- routing policy version
- previous build retained until health/golden routes pass

## Packs
- schema version compatibility
- old active pack retained until new verified
- app refuses incompatible pack with actionable message
