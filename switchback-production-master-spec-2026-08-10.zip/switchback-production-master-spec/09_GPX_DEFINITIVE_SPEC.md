# GPX — Definitive Specification

## Supported inputs

- track
- route
- waypoints
- multiple tracks
- multiple segments
- timestamps
- elevation

Original artifact is immutable.

## Processing

1. streaming parse
2. validation
3. dedupe impossible coordinates
4. detect teleports/gaps
5. preserve segment boundaries
6. map match
7. split high-confidence match vs unmatched track-only spans
8. route fingerprint
9. surface/elevation/curvature analysis
10. optional RIG evidence event generation based on provenance

## Unmatched spans

An unmatched span is not automatically bad.

It may be:
- legitimate trail absent from OSM
- private/illegal path
- poor GPS
- old road
- ferry/water crossing
- mapping gap

Display:
`Track guidance — road data unavailable`

Do not silently snap it to a nearby highway.

## GPX route detail

Show:
- distance
- estimated duration
- match %
- unmatched %
- surface probability
- road classes
- elevation
- mapped MVUM overlap
- community corridor overlap
- likely fuel gaps
- data confidence
- creator notes
- AI summary grounded only in structured facts/notes

## Join-route algorithm

Given current location and ordered route geometry:

Candidate entries:
- original start
- nearby forward route points
- meaningful waypoint boundaries
- route-leg boundaries

Score:

```text
entry_score =
- approach_time
- backwards_travel
- semantic_skip_penalty
- direction_mismatch
+ useful_remaining_route
+ user_preference
```

Reject pathological entries.

Offer:
- Best join
- Original start
- Choose entry

## Continuous session

Navigation trip:

`Approach leg → GPX leg(s) → Finish`

Entering GPX does not emit final arrival.

Arrival only when:
- final GPX endpoint reached
- user selected approach-only mode
- user explicitly ends ride

## Track-only navigation

For unmatched trail:
- breadcrumb/track following
- cross-track distance
- direction arrow
- no invented turn instructions
- no automatic reroute through nearby road unless user chooses it

## Export

Always:
- generic Track
- Route
- Track + waypoints
- Original
- Recorded ride

Compatibility presets become user-facing only after real import testing.

Targets:
- Gaia
- onX Offroad
- Garmin
- OsmAnd
- Rever
- Kurviger
- Scenic

## Simplification

Protect:
- start/end
- maneuver anchors
- shaping points
- surface transitions
- road requirement anchors
- notes/waypoints

Error-bounded simplification.

## Provenance

Derivative route stores:
- parent route
- parent revision
- changed-segment %
- creator
- modification timestamp
- public/private source

Never overwrite another user's published route revision.
