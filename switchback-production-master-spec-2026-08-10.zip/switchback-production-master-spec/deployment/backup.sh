#!/usr/bin/env bash
set -euo pipefail

ROOT="${SWITCHBACK_DATA_ROOT:-/var/lib/switchback}"
DEST="${1:-/var/backups/switchback}"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"

mkdir -p "$DEST/$STAMP"

# SQLite consistent backup; adapt exact DB path to deployment.
sqlite3 "$ROOT/app/switchback.sqlite" ".backup '$DEST/$STAMP/switchback.sqlite'"

tar -C "$ROOT" -czf "$DEST/$STAMP/artifacts.tgz" artifacts

sha256sum "$DEST/$STAMP/"* > "$DEST/$STAMP/SHA256SUMS"

echo "Backup complete: $DEST/$STAMP"
