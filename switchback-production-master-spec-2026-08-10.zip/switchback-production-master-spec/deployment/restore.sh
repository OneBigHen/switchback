#!/usr/bin/env bash
set -euo pipefail

BACKUP="${1:?backup directory required}"
ROOT="${SWITCHBACK_DATA_ROOT:-/var/lib/switchback}"

sha256sum -c "$BACKUP/SHA256SUMS"

mkdir -p "$ROOT/app" "$ROOT/artifacts"
cp "$BACKUP/switchback.sqlite" "$ROOT/app/switchback.sqlite"
tar -C "$ROOT" -xzf "$BACKUP/artifacts.tgz"

echo "Restore staged. Run health checks before exposing traffic."
