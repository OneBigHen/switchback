# Mobile UX — Definitive Specification

## Design language

Do not build a generic dashboard.

Avoid:
- grids of cards
- giant permanent side panels
- dozens of chips on home
- glassmorphism
- gradient SaaS styling
- always-visible diagnostics
- tiny icon-only ride controls

Use:
- persistent full-screen map
- strong type hierarchy
- restrained sheets
- deliberate route color
- high contrast
- map/provenance detail only when requested

## Persistent map

MapLibre should remain mounted across Explore → Plan.
Ride can reuse the same map surface if lifecycle allows.

No remount just because a sheet changes.

## Home / Explore

Visible:
- search pill: `Where do you want to ride?`
- current location
- bottom peek
- `Just Ride`
- `Make a Loop`
- `Import GPX`
- small Library entry

Nothing else.

## Search

Expanded sheet:
- free text
- addresses/places
- saved routes
- community routes
- recent
- home

AI interpretation appears as normal product behavior, not a chatbot.

Example interpretation:

```text
3 hr loop
Dual Sport
Gravel preferred
Easy/moderate dirt
Lunch halfway
Avoid highways
Avoid PA-611

[Plan ride] [Adjust]
```

## Plan results

Map with 2–3 routes.

Bottom sheet:

```text
BEST RIDE
Ridge & Gravel
2h 48m · 112 mi
34 mi unpaved · +21 min vs fastest
3 high-confidence community corridors
6% surface unknown

[Start ride]
Why this route   Customize
```

Alternative labels are generated from measured differences:
- More Gravel
- Faster Mixed
- Twistier Pavement
- Scenic
- Fastest

## Customize

Sections:
- bike
- surface tolerance
- technical difficulty
- time/detour
- avoid
- stops
- road requirements
- advanced

Surface matrix:
- Pavement: Prefer/OK/Avoid
- Gravel: Prefer/OK/Avoid
- Dirt: Prefer/OK/Avoid
- Rough trail: Prefer/OK/Avoid

## Edit

Focused mode:
- drag points
- add via
- sketch corridor
- tap road → Must / Prefer / Avoid
- avoid polygon
- reverse
- undo/redo

No unrelated library/settings controls visible.

## Portrait Ride HUD

Top:
- giant next-turn arrow
- distance
- street/road
- "then" cue

Center:
- map

Bottom:
- ETA
- remaining distance/time
- mute
- overview
- more

Free Ride banner appears above bottom dock.

## Landscape Ride HUD

Left 35–40%:
- maneuver
- distance
- road
- then
- ETA

Right:
- map

Controls stay accessible without scrolling.

## Touch targets

Planning:
- min 44px
- target 48px

Ride:
- min 56px
- primary 64–72px

## Gloves / mount

Never require:
- small swipe target
- precise map tap for routine action
- long text reading
- multiple modal confirmations while moving

Destructive actions such as End Ride can require a deliberate hold/two-step under More.

## Day/night

Ride theme automatically adapts by local daylight if enabled.
Manual override available.
Map style transitions must not destroy active sources/route state.

## Explorer Mode

Dedicated layer drawer:
- Clean
- Topo
- Satellite
- 3D terrain
- community routes
- RIG heatmap
- curvature
- gravel/unpaved
- MVUM
- public land
- weather/radar
- signals
- closures/incidents if available
- route provenance

Every expensive layer is:
- code split
- lazy loaded
- removed when disabled
- absent from core ride bundle/runtime

## Accessibility

- WCAG AA
- reduced motion
- 200% text target
- screen reader live regions throttled
- no meaning by color alone
- keyboard navigation on desktop
- focus retained correctly when bottom sheets move
