# 14 — Test & Release Gates

## Existing quality system

The repo already has:
- lint
- TypeScript
- Vitest
- critical Playwright
- mobile Safari/WebKit targets
- real-router tests
- PWA tests
- live smoke
- routing benchmark

Keep and expand this instead of replacing it.

# Test pyramid

## Unit
- scoring
- eligibility
- GPX parsing
- map-match result normalization
- route fingerprints
- segment evidence aggregation
- preference updates
- Free Ride ranking
- identity envelope validation
- offline manifest validation

## Integration
- GraphHopper request/response
- worker ingestion
- RIG query
- region pack
- WebAuthn
- encrypted sync blob round trip
- community publish

## E2E
Critical rider journeys.

## Field
Physical iPhone + motorcycle/car simulation.

# Golden route corpus

At minimum:
- Hatboro → New Hope/Stockton
- Hatboro recreational loop
- Hatboro → Jim Thorpe
- PA state forest/gravel samples
- route with known bad highway-heavy alternative
- route with gravel corridor
- GPX community route
- cross-state PA/NJ
- no-cell Ride Pack fixture

Assertions:
- legal constraints
- duration bounds
- known road inclusion/exclusion
- candidate diversity
- no near-duplicate three-card set
- explanation facts match metrics

Do not assert exact geometry unless the route is specifically a regression fixture.

# Critical E2E journeys

1. current location → destination → choose → ride
2. 2-hour loop → choose → ride
3. natural language intent
4. location denied
5. router unavailable
6. Places unavailable → fallback
7. import GPX → inspect
8. import GPX → join nearest
9. export generic track
10. start Free Ride
11. accept Free Ride suggestion
12. ignore suggestions → quiet period
13. offline Ride Pack
14. offline reroute
15. install region
16. PWA update while not riding
17. PWA update deferred during ride
18. community browse anonymous
19. create Switchback ID
20. upload route
21. comment/report
22. sync encrypted object
23. edit route road requirement
24. Explorer Mode layer lifecycle

# Physical device matrix

Required:
- current iPhone Safari
- iPhone installed PWA
- iPad
- landscape phone mount
- Chrome Android if community testers have one

Optional:
- desktop Chrome/Safari/Firefox

# Field acceptance

Before production label:
- 5+ real rides
- at least 2 offline/weak-signal rides
- one 2+ hour ride
- Free Ride test
- GPX join test
- route departure/rejoin test
- heat/battery observation
- no blocker bugs

Before community release:
- 3 external riders complete one route each without developer assistance.
