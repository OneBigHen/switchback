# 05 — UI / UX System

## Design objective

The app must not look like a collection of generated cards.

It should feel like a navigation product designed by somebody who actually rides:
- map-first
- sunlight-readable
- thumb-friendly
- glove-tolerant in Ride mode
- minimal cognitive load
- powerful editing available without permanently occupying the screen

## Mobile is the canonical product

Design at:
- iPhone portrait
- iPhone landscape mounted
- 10-inch iPad/tablet
- desktop

Desktop may gain more simultaneous panels, but it must use the same information architecture.

# Global layout

## Map canvas
`position: fixed; inset: 0`

The map never re-mounts when moving among Explore/Plan/Library overlays. Re-mounting MapLibre is expensive and visually disruptive.

## Top safe area
One floating search/header surface.

## Bottom interaction zone
A sheet with three detents:
- peek: ~120–150 px
- half: ~45–52vh
- full: ~88–92vh

Use safe-area insets.

## Touch sizing
Planning:
- minimum 44 px
- preferred 48 px

Ride mode:
- minimum 56 px
- primary actions 64–72 px

# Home / Explore

Visible by default:
- search pill: **Where do you want to ride?**
- current-location control
- bottom peek card
- three actions:
  - **Just Ride**
  - **Make a Loop**
  - **Import GPX**
- optional small Library entry

Nothing else.

No permanent profile chips.
No diagnostics.
No road locks.
No layer toolbar.
No giant brand panel.

## Search behavior

Tap search → full-height search sheet.

Input accepts:
- place/address
- natural-language ride request
- pasted coordinate
- route/library name

Show:
- recent places
- home
- saved rides
- community results
- search provider results

A small AI glyph indicates free-text interpretation is available; do not make the UI feel like a chatbot.

Examples can appear as placeholder/help text, not six permanent chips.

# Intent result

For:
"3 hour gravel loop, easy stuff, lunch halfway"

Show a compact parsed intent confirmation:

```text
3 hr loop
Dual Sport · Gravel preferred
Easy/Moderate dirt
Lunch near halfway
Avoid highways

[Plan ride]        [Adjust]
```

The user can edit chips; they never need to edit JSON/advanced sliders.

# Route choice

Map shows 2–3 routes.

Bottom sheet card:

```text
RECOMMENDED
Pine Barrens Backroads
2h 48m · 112 mi
34 mi unpaved · 18% more curves
+21 min vs fastest

Why this route >
[Start ride]
```

Swipe or horizontally select alternatives:
- Best Ride
- More Gravel
- Fastest

Labels should reflect actual characteristics, not permanent engine names.

# Customize

`Customize` opens the expert surface.

Sections:
- Bike
- Surface
- Road character
- Time/distance tolerance
- Avoid
- Must / Prefer / Avoid roads
- Add stops
- Draw/sketch corridor
- Advanced route evidence

This is where the current powerful tools belong.

### Surface control
Use a compact tolerance control:

```text
Pavement      Preferred / OK / Avoid
Gravel        Preferred / OK / Avoid
Dirt          Preferred / OK / Avoid
Rough trail   Preferred / OK / Avoid
```

Bike defaults initialize it.

### Technical difficulty
Off-road:
`Easy — Moderate — Technical`

Never infer "technical" solely from `surface=unpaved`; use smoothness/tracktype/grade/community evidence and confidence.

# Route editing

Editing is a mode, not a permanent panel.

Map:
- draggable start/end/via
- sketch corridor
- tap road → Prefer / Must / Avoid
- avoid polygon
- undo/redo

Bottom:
- route stats
- active constraints
- Done

Hide unrelated actions.

# Ride mode

## Portrait

Top 35–42%:
- next maneuver glyph
- distance
- road/street
- "then" instruction

Center:
- map

Bottom dock:
- ETA / remaining distance
- mute
- overview
- more

Free Ride suggestion appears as a temporary non-blocking banner above the dock.

## Landscape mounted

Left 34–40%:
- maneuver
- distance
- next road
- ETA

Right:
- map

Bottom/right compact controls.

This is critical for motorcycle mounts.

## Ride mode interaction

No tiny X.
"End ride" lives under More, except emergency/obvious exit affordance.

Off-route:
- preserve route first
- show `Rejoin` and `Replan from here`
- auto-reroute only under the configured policy
- never demand repeated U-turns after obvious intentional exploration

# GPX import UX

After selecting a file:

```text
PA–NY ADV Loop
711 mi · estimated 4 days
~288 mi mapped gravel/unpaved
Moderate · some surface uncertainty

Imported track
92% matched to routable motorcycle roads

[View route]
[Join & ride]
[Save]
```

Expandable:
- AI summary
- surface chart
- elevation
- fuel gaps
- notes
- source provenance
- unmatched sections

If currently 40 miles away:
`Join & ride` asks:
- Route to original start
- Join nearest sensible point
- Choose entry point

Default recommendation should usually be nearest sensible forward entry point unless the route semantics require starting from the beginning.

# Library

Top tabs:
`Mine | Community`

Mine:
- Saved
- Imported
- Recorded
- Downloads

Community:
- Map/list
- Near me
- ADV
- Gravel
- Paved scenic
- filters

No feed algorithm.

# Community route detail

Hero is a map/elevation summary, not a social post.

Information:
- distance/time
- surface
- difficulty
- region
- community evidence
- description
- route notes
- comments
- version/update date

Actions:
- Ride
- Save copy
- Modify
- Export GPX

# Explorer Mode ("God Mode")

Accessible from map layers button or Settings → Explorer Mode.

Layer sheet:
- Clean / Topo / Satellite / Terrain / 3D
- Community routes
- Road intelligence heatmap
- Curvature
- Gravel/unpaved
- USFS MVUM
- Public lands
- Weather/radar
- traffic signals
- closures/incidents if provider enabled
- elevation/terrain shading
- route evidence/provenance

Rules:
- lazy-load every expensive layer
- layer state not mounted when off
- show source and last-updated info
- never let Explorer Mode pollute normal Ride mode

# Visual system

Avoid the generic "AI SaaS" aesthetic:
- no excessive rounded white cards floating everywhere
- no gradient blobs
- no gratuitous glassmorphism
- no dashboard tiles on the main map

Use:
- strong typography
- restrained radius
- clear hierarchy
- high contrast
- map-derived neutral palette
- one brand accent
- surface colors only where semantically meaningful

# Accessibility
- AA contrast minimum
- reduced motion
- text scales to 200%
- voice guidance does not rely on color
- all controls reachable by keyboard on desktop
- large ride touch targets
- screen-reader live regions rate-limited; do not announce every GPS update
