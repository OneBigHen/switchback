# 00 — Product North Star

## Product statement

Switchback is **Google Maps for people who ride for the road, not merely the destination**.

It is not a GIS console. It is not a forum. It is not a generic trip planner with motorcycle colors. It is a motorcycle road-intelligence and navigation product.

Primary rider:
- ADV / dual-sport rider.
- Often leaves with no exact destination.
- Values gravel, unpaved legal roads, secondary roads, curves, elevation, scenery, low stop density, and route character.
- Frequently consumes GPX tracks from Facebook groups, forums, friends, Gaia, onX, Garmin, etc.
- May ride through weak/no cellular coverage.
- Uses the same phone for navigation and media.

Secondary rider:
- Touring / cruiser / street rider who wants scenic and curvy paved routes.

## Jobs to be done

### 1. Destination
"Take me to X, but give me a route I will enjoy."

Always retain a direct/fast baseline. Recreational choices must show the cost of fun in time/distance.

### 2. Loop
"I have 90 minutes / 3 hours / 180 miles. Give me a good ride and bring me back."

The duration/distance target is a hard planning constraint band, not just a label.

### 3. Free Ride
"I want to go ride. I don't know where."

The rider starts moving. Switchback observes heading and context and occasionally presents good roads that are reachable ahead.

### 4. GPX
"Someone gave me a GPX. Make it useful."

Import, map-match, analyze, describe, inspect, join, navigate, modify, save, publish, and export.

### 5. Community discovery
"Show me routes or road segments riders actually use around here."

No forum feed. The community object is the route and its road evidence.

## Product principles

### Map owns the screen
The map should occupy the entire viewport. Controls float over it or live in a bottom sheet.

### Progressive disclosure
The normal rider should never see 80% of the tuning controls. The expert can reach all of them in one or two additional taps.

### Evidence over claims
Never label a road "safe", "verified", "open", or "legal" unless the evidence supports that exact claim. Prefer:
- "Mapped motorcycle access"
- "USFS MVUM designated"
- "Community ridden"
- "Surface data confidence: medium"
- "Reported closure"
- "Access unknown"

### Never punish exploration
If the rider intentionally deviates, Switchback should not incessantly demand a U-turn. It should infer whether the rider is exploring, offer rejoin/replan options, and preserve the selected route when asked.

### Offline truthfulness
The UI must distinguish:
- map available offline
- selected route available offline
- turn cues available offline
- rerouting graph available offline
- search/POI available offline
- weather unavailable offline

### AI is an interface
AI interprets, summarizes, compares, and explains. Deterministic systems decide graph legality and produce routes.

## Scope for v1 production

Required:
- Map-first PWA
- Destination / Loop / Just Ride
- ADV/gravel-first bike policies
- Reliable turn-by-turn browser navigation
- GPX import/export
- Road Intelligence Graph
- Community route upload/read
- Optional pseudonymous identity
- Local-first saved library
- Regional data manager
- Ride Packs
- Offline route viewing and rerouting where a graph pack exists
- Self-host deployment
- Error/health/diagnostic surfaces
- iPhone-centric physical testing

Deferred until after production:
- Full social feeds
- Clubs/forums/direct messaging
- Native iOS/Android apps
- CarPlay/Android Auto
- Pairwise ML ranker
- Live traffic subscription if it breaches budget
- Spotify integration
- Public federation among independent Switchback servers
- Commercial billing/subscriptions
