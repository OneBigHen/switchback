# 12 — Navigation & PWA

## Navigation product requirements

Turn-by-turn is a first-class feature, not a preview.

Need:
- map matching
- maneuver progress
- then-turn cues
- voice
- reroute
- rejoin
- wake lock
- route resume after foreground/background
- GPS uncertainty handling
- ride recording
- offline continuation
- GPX track guidance for unmatched spans

## GPS state

Keep a filtered state:
- raw fix
- smoothed position
- heading
- speed
- accuracy
- matched route position
- match confidence

Do not move the route progress backward because one GPS fix jumps.

Use hysteresis and direction-aware matching.

## Off-route policy

States:
- `on-route`
- `uncertain`
- `deviating`
- `off-route`
- `intentional-explore`
- `rerouting`
- `arrived`

Do not reroute on a single off-corridor sample.

## Rejoin

When preserving original route:
- evaluate forward rejoin points
- avoid sending rider backward unless necessary
- respect Must roads
- show skipped distance

## Background limitations

A pure PWA on iOS has limitations compared with native navigation.

Production documentation must state tested behavior:
- screen on / wake lock
- screen locked
- app backgrounded
- audio speech
- GPS update behavior

Do not claim native-grade background navigation if the browser platform cannot deliver it.

Long term, a thin native wrapper can reuse the PWA if background navigation becomes a hard requirement.

## Service worker

Current bounded caches are a good start.

Production rules:
- never cache `/api` success as fake offline state
- version shell caches
- controlled update prompt during a ride
- never activate a breaking service worker in the middle of navigation
- offline home shell must load
- route pack reads come from IndexedDB/OPFS rather than general tile cache where possible

## Install/update UX

Settings:
- Installed version
- New version available
- Update after ride
- Refresh now

If actively riding:
`Update downloaded — will apply after ride.`

## Voice

Use SpeechSynthesis initially.
Queue management:
- cancel obsolete instructions
- distance thresholds
- no repeated spam
- respects mute
- Free Ride suggestion voice is brief and less frequent than maneuver speech
