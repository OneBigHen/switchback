# 01 — Current State Audit

This blueprint does **not** assume the current repo is bad. It has a surprisingly strong capability base. The failure is that product complexity, state ownership, data confidence, and UI structure have outrun the architecture.

## Confirmed strengths in the current repository

The repository already contains:
- Next.js 16 / React 19 / TypeScript
- MapLibre
- GraphHopper 11 primary routing
- Optional Valhalla
- Google Places + Photon fallback
- route profiles and route comparison
- timeboxed loops and destinations
- path details / road and surface mix
- GPX import/export
- local IndexedDB storage with Dexie
- weather integration
- a PWA service worker
- an offline graph v2 router
- road locks / requirements
- route recording/replay
- Free Ride state and UI
- preference learning
- a substantial Vitest + Playwright suite
- real-router and PWA test targets

## Important repo evidence

The recovery audit already found and/or addressed several serious problems:
- `PlannerShell` was a god component (the baseline audit recorded ~1,440 lines, 28 `useState`, 14 `useEffect`, ~73 imports).
- Free Ride originally synthesized road class, scenic, traffic, access, and confidence.
- Service worker tile caching was unbounded at baseline; it has since been bounded.
- Bike settings, road-lock plumbing, privacy redaction, segmented request propagation, and timebox wording have received recovery work.
- Offline v2 exists, but regional E2E and deeper product integration remain incomplete.

Current code still exposes an important warning in `feature-flags.ts`: Free Ride is enabled but documented as experimental because the current endpoint still needs graph-backed candidate evidence.

## Primary current risks

### A. Product shell overload
`PlannerShell.tsx` remains responsible for too many domains:
- planner state
- routing lifecycle
- location
- route research
- recording
- Free Ride
- offline packs
- library
- map layers
- UI navigation
- preferences

Even if it has been reduced from the original baseline, its role is still too broad.

### B. UI overload
`PlannerDeck.tsx` combines:
- free text
- destination/loop
- profiles
- bike
- voice
- road locks
- offline
- editing
- route preparation
- research

This is why the product visually reads as a tool collection instead of a navigation app.

### C. Free Ride source quality
The ranking function has useful concepts (GPS confidence, workload suppression, directionality, expiry, cooldown, route scoring), but candidate generation is the missing center. Free Ride must be rebuilt around real graph segments and real routeable detours.

### D. Route score confusion
The current scoring code has a useful normalized feature model, but it mixes:
- profile weights
- preference fit
- confidence
- safety
- ETA
- features
into a single number too early.

The replacement should separate:
1. **Eligibility** — can/should this be considered?
2. **Evidence confidence** — how much do we know?
3. **Ride utility** — how desirable is it for this rider/intent?
4. **Route diversity** — is it meaningfully different from the other options?
5. **Explanation** — why is it being shown?

### E. Offline memory/storage risk
The current offline v2 router merges graph tiles into in-memory JS `Map`s before search. This can be acceptable for small Ride Packs but is dangerous for full state packs in a browser. State-scale offline routing must be explicitly bounded, workerized, indexed, and measured.

### F. Heavy work in the wrong runtime
The Next.js process must not become the worker for:
- GPX bulk ingestion
- OSM graph builds
- route evidence aggregation
- regional package generation
- AI batch descriptions

These belong in background jobs / separate workers on the LXC.

## Immediate cut candidates

Remove from production core:
- Spotify UI and OAuth/session code from default build path
- redundant planner controls
- duplicate profile concepts (`gravel`, `avoid-highways`, `neural` as top-level engine profiles)
- unsupported marketing/safety claims
- static scenic imagery that does not prove route quality
- duplicate download controls
- any diagnostic controls in the default rider flow
- any dead provider abstraction or zero-reference module discovered in P02

Keep the seams so optional modules can be reintroduced.
