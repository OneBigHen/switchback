# 19 — Master Roadmap: 36 Phases

The phase files contain executable details. This is the program overview.

## G1 — Baseline and containment

### P01 — Freeze, inventory, baseline
Create reproducible repository, performance, route-quality, and UI baselines.

### P02 — Dead code & feature disposition
Delete zero-value/dead surfaces and isolate optional features.

### P03 — Memory observability
Instrument browser/server/router/worker memory and storage.

### P04 — Production telemetry & failure taxonomy
Structured errors, health, request ids, provider degradation.

## G2 — Architecture and memory

### P05 — App shell / mode architecture
Separate Explore, Plan, Ride, Library shells.

### P06 — Planner orchestration split
Move business lifecycle out of PlannerShell.

### P07 — Canonical route entity cache
Eliminate geometry duplication and stale route retention.

### P08 — Map lifecycle + browser leak remediation
Stable MapLibre mount, listeners/timers/sources/workers audited.

## G3 — Road intelligence and routing

### P09 — Canonical road segment schema
Create stable segment identity and intrinsic feature pipeline.

### P10 — GPX bulk ingest & map matching
Turn existing ~100 GPXs into matched route evidence.

### P11 — Road evidence aggregation
Independent-source weighting, dedupe, route role, confidence.

### P12 — Eligibility pipeline
Hard constraints before ranking.

### P13 — Route utility V2
Transparent multidimensional score.

### P14 — Candidate generation + diversity
Interest anchors and maximal-marginal route choice.

### P15 — PA golden-route tuning
Tune only against reviewed fixtures; freeze v1 weights.

## G4 — New UX

### P16 — Design system + responsive map shell
Replace generic panels.

### P17 — Explore/search/free-text
Home experience.

### P18 — Route choice + explanations
2–3 meaningful options.

### P19 — Expert Customize/Edit
Progressive disclosure for advanced controls.

### P20 — Library + Explorer Mode
Mine/Community shell and optional rich layers.

## G5 — Navigation + Free Ride

### P21 — Ride HUD V2
Portrait/landscape/glove-friendly navigation.

### P22 — Navigation reliability
GPS matching, off-route, rejoin, resume.

### P23 — Free Ride graph candidate engine
Real ahead-of-rider candidates.

### P24 — Free Ride interruption/personalization
Quiet policy, feedback, head-home behavior.

## G6 — GPX + offline + regions

### P25 — GPX intelligence UI
Import analysis and route detail.

### P26 — GPX join-route navigation
Approach→GPX continuous session.

### P27 — Universal export
Interoperable GPX variants.

### P28 — Offline graph worker
Bounded tile loading/search.

### P29 — Region/Ride Pack product
State UX, manifests, atomic install, server territory builds.

## G7 — Community + identity + AI

### P30 — Community route backend
Routes/revisions/artifacts/comments.

### P31 — Passkey identity + privacy
Pseudonymous write identity.

### P32 — Encrypted private sync
Local-first cross-device data.

### P33 — AI grounded descriptions/semantic search
AI layer over facts, not routing.

## G8 — Production and release

### P34 — Security/abuse/deployment hardening
Headers, rate limits, upload defenses, Docker setup.

### P35 — Soak/device/field beta
Battery, thermal, memory, offline, external rider drills.

### P36 — Production release
Migration, docs, rollback, tagged release, owner runbook.

## Schedule philosophy

Do not assign calendar weeks until P01 measurements exist.

A phase can take hours or days. The gate matters more than the estimate.

The first shippable private beta target is **after P29**. Community sharing is layered afterward so it cannot delay the core riding product.
