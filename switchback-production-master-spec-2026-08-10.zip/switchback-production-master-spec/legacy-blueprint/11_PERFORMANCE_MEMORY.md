# 11 — Performance & Memory Program

Memory is a P0 production blocker.

## Budgets

These are initial engineering budgets; measure and revise with evidence.

### Browser — iPhone-class device
Explore idle:
- JS heap target < 100 MB after stabilization
- no monotonic growth while panning for 10 minutes

Plan with 3 candidates:
- < 160 MB JS heap target
- route geometries not duplicated across React/Zustand/MapLibre

Ride:
- < 140 MB JS heap target
- 2-hour simulation must plateau
- GPS samples stored in bounded ring buffers unless recording stream is persisted incrementally

Explorer Mode:
- allowed higher temporary memory
- turning layers off must release source/layer references and large arrays

### Web Node process
Target steady-state:
- small enough to run with `--max-old-space-size=512` initially
- no graph builds or huge GPX arrays

### Worker
Separate heap limit, e.g. 1–2 GB depending jobs.
One memory-heavy region build at a time.

### GraphHopper
Explicit JVM heap based on active territory, not machine total.

## Instrumentation

Build a dev-only `/diagnostics/performance` page.

Record:
- `performance.memory` where available
- DOM node count
- active timers
- active geolocation watches
- active event listeners where instrumentable
- MapLibre source/layer counts
- route entity cache count/bytes estimate
- IndexedDB usage
- Cache Storage usage
- offline graph worker memory/loaded tile count
- request counts
- service worker cache entry counts

## Memory soak script

Automate with Playwright/Chromium CDP where available:

1. cold load
2. idle 5 min
3. pan/zoom 5 min
4. search
5. plan 3 routes
6. choose route
7. enter edit
8. exit edit
9. enter ride
10. simulate 30 min GPS
11. reroute 10×
12. exit ride
13. clear route
14. repeat 3×

Take heap snapshots at checkpoints.

## Likely leak classes

Audit:
- MapLibre event handlers
- custom map sources/layers not removed
- geolocation watches
- `setInterval`
- window/document listeners
- long route arrays captured by callbacks
- closures in planner controller
- stale route alternatives
- IndexedDB live subscriptions
- worker references
- AbortController lifecycle
- service worker/cache growth
- repeated imported GPX data
- recording arrays
- route research results
- React Strict Mode assumptions

## Large data rules

- geometries stored once
- UI consumes route summary + id
- simplify geometry by zoom/display purpose
- use typed arrays in workers when beneficial
- transfer ArrayBuffers instead of copying
- stream GPX processing
- page community route lists
- spatial queries return viewport/route corridor only
- never load all community road evidence into browser

## Performance gates

No phase can claim a memory fix without:
- before/after measurement
- repeatable scenario
- retained-object evidence or strong causality
- regression test/diagnostic where feasible

"Feels faster" is not evidence.
