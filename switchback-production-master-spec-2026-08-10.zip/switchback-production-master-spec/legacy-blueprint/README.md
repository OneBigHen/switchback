# Switchback Production Blueprint

**Blueprint date:** 2026-08-10  
**Repository audited:** `OneBigHen/switchback` on `main`  
**Product goal:** A map-first, local-first PWA for ADV / dual-sport riders that discovers, creates, explains, navigates, imports, exports, and learns great motorcycle roads.

This package is the authoritative rebuild plan. It is intentionally more prescriptive than a normal product roadmap because execution may be delegated to a cheaper coding model that can take shortcuts unless the boundaries, tests, and acceptance conditions are explicit.

## North star

> **Switchback should be dramatically simpler than the current application until a rider asks for control, then dramatically more powerful.**

The core experience is:

`Explore → Plan → Ride → Save/Share`

with three first-class entry points:

- **Where to?** — destination routing with a better-road alternative.
- **Make a Loop** — time/distance constrained recreational routing.
- **Just Ride** — no destination; Switchback quietly surfaces worthwhile roads ahead.

A fourth equally important path is **Import GPX**, because ADV riders already live in GPX ecosystems.

## Major architectural decisions

1. **Do not use an LLM/RAG system as the routing engine.** Use a spatial road graph plus evidence and deterministic scoring. RAG is useful for semantic route search, descriptions, notes, and AI assistance.
2. **Build a Road Intelligence Graph (RIG).** Every vetted GPX is map-matched to canonical road segments. It becomes segment evidence, not merely another file in a library.
3. **Free Ride becomes the differentiator.** It is a graph-backed, direction-aware, low-interruption recommendation engine, not a synthetic suggestion endpoint.
4. **Local-first remains the default.** No sign-in is required to plan, ride, save, import, export, or use offline data.
5. **Optional pseudonymous identity** is used only for community writing and encrypted sync. No email/password requirement.
6. **Heavy processing is moved off the Next.js/UI process.** Routing, GPX ingestion, regional builds, road intelligence aggregation, and AI enrichment run in dedicated services/workers.
7. **Offline is a capability model, not a checkbox.** Region Packs and smaller Ride Packs advertise exactly what they contain.
8. **ADV/gravel is primary.** Touring/street is supported through bike and surface policy, not by diluting the main product.
9. **Spotify is removed from the production core** but a clean accessory/provider seam remains so it can return later without contaminating navigation.
10. **"God Mode" returns as Explorer Mode**, a deliberate optional layer workspace for weather, MVUM, traffic signals, topo, satellite, 3D, route intelligence, community routes, and data provenance.

## Execution order

Read these before coding:

1. `00_PRODUCT_NORTH_STAR.md`
2. `01_CURRENT_STATE_AUDIT.md`
3. `02_TARGET_ARCHITECTURE.md`
4. `03_ROAD_INTELLIGENCE_ALGORITHM.md`
5. `04_FREE_RIDE_ENGINE.md`
6. `05_UI_UX_SYSTEM.md`
7. `19_MASTER_ROADMAP.md`
8. `18_EXECUTION_RULES_FOR_LUNA.md`
9. Then execute `phases/P01_...` through `P36_...` in order.

Do not start a later phase because it appears easy. Each phase has a gate.

## Release gates

The 36 implementation phases roll into eight release gates:

| Gate | Purpose | Phases |
|---|---|---|
| G1 | Baseline + containment | P01–P04 |
| G2 | Architecture + memory | P05–P08 |
| G3 | Road intelligence + routing | P09–P15 |
| G4 | New UX | P16–P20 |
| G5 | Navigation + Free Ride | P21–P24 |
| G6 | GPX + offline + regions | P25–P29 |
| G7 | Community + identity + AI | P30–P33 |
| G8 | Production + field release | P34–P36 |

## Non-negotiable definition of success

A rider in Hatboro can say:

> "I've got three hours. Give me gravel and twisties northwest of here, nothing technical, lunch halfway, and don't send me down 611."

Switchback produces genuinely different legal candidates, explains them, navigates the chosen route, tolerates intentional deviations, can suggest an interesting road during Free Ride, continues through signal loss when the required pack is installed, imports an external GPX and intelligently joins it, and exports the final ride in a form that can be consumed by common GPX apps/devices.

See `acceptance/PRODUCTION_DEFINITION_OF_DONE.md`.
