# 06 — GPX Ingest, Join, Navigate, Export

## Why this is first-class

The ADV community already exchanges routes through GPX. Switchback wins by making those files smarter without trapping riders inside Switchback.

# Import

Support:
- GPX tracks (`trk`)
- routes (`rte`)
- waypoints (`wpt`)
- multiple tracks/segments
- optional time/elevation

Preserve original file.

## Analysis outputs

After map matching:
- matched %
- unmatched spans
- distance
- estimated moving time
- surface distribution
- road-class distribution
- elevation/ascent
- curvature
- stop density
- highway fraction
- official MVUM overlap where available
- community road overlap
- likely fuel gaps based on POIs and bike range
- data confidence

AI generates a description only from these structured facts + user notes.

Never fabricate trail difficulty or legal access.

# Join-route algorithm

This directly solves the screenshot problem where navigation reaches GPX point 1 and terminates.

Given current location + ordered GPX geometry:

1. Map-match GPX to road segments.
2. Find candidate entry points along the route.
3. Reject candidates that create unreasonable reverse travel or skip required semantic start.
4. Compute approach route to each candidate.
5. Score:
   - approach time
   - route direction compatibility
   - amount of GPX skipped
   - whether route is loop or point-to-point
   - waypoint semantics
   - user preference
6. Recommend:
   - Original start
   - Best join
   - Choose manually

When approach reaches the entry point, **the navigation session transitions to the GPX route without ending**.

The UI should show one continuous trip:
`Approach → GPX → Finish`.

# Handling tracks that are not routable

Do not force every GPX through GraphHopper if it contains legitimate off-road track geometry not present in OSM.

Classify spans:
- routable road match
- routable trail match
- unmatched track-only

Navigation can follow the track as a breadcrumb for unmatched spans, clearly marking:
`Track guidance — no routable road data`

Automatic rerouting around an unmatched span must not silently alter the creator's route.

# Export profiles

Always offer generic GPX.

Export variants:
- **Track** — densified/simplified geometry, safest interoperability
- **Route** — via/shaping points + cues where compatible
- **Track + waypoints**
- **Original GPX** if imported unchanged
- **Recorded ride**

Later add tested presets:
- Garmin
- Gaia GPS
- onX Offroad
- OsmAnd
- Rever
- Kurviger
- Scenic

Do not claim compatibility until tested with each target.

# GPX simplification

Use error-bounded Douglas-Peucker or Visvalingam simplification, but protect:
- maneuvers
- shaping points
- surface transitions
- road requirement anchors
- route start/end
- community note points

Preset should state max points and error tolerance.

# Provenance

A modified community route becomes a derivative copy:
- parent route id
- original uploader
- modification timestamp
- changed segment percentage

Never overwrite somebody else's published GPX.
