# 13 — Security, Privacy & Moderation

## Threat model

Primary risks:
- exposed routing services
- API key leakage
- upload abuse
- GPX parser abuse
- XSS in route/comments
- malicious community text prompt injection
- path traversal in uploaded filenames
- huge uploads / zip bombs
- CSRF/session abuse
- WebAuthn/session errors
- location privacy
- public-route home leakage
- request/amplification abuse

## Network

Internet:
`Caddy/Cloudflare → switchback-web`

Private only:
- GraphHopper
- Valhalla
- worker internal endpoints
- SQLite/file storage
- admin metrics

## Upload rules

GPX:
- size cap
- parse as XML with external entities disabled
- no filesystem path from uploaded filename
- canonical generated object id
- content-type is not trusted
- quotas per identity/IP
- worker timeout
- point-count cap with streaming/simplification path
- original stored outside web root

## API protection

- rate limit search/route/AI/upload/community writes
- CSRF for session-authenticated mutations
- strict CORS
- CSP
- HSTS at edge
- X-Content-Type-Options
- Referrer-Policy
- Permissions-Policy
- server-only provider secrets
- structured input validation everywhere

## Community content

Store comments as plain text / sanitized limited markdown.
No arbitrary HTML.

AI sees community text as quoted data only.

## Location

Default:
- current live location stays client-side except requests necessary to plan/search
- raw ride trails stay local unless user explicitly syncs/uploads
- community upload screen shows privacy warning
- optional home privacy zone

## Logs

Never log:
- full raw GPS trails by default
- passkey credential secrets (none should exist server-side)
- sync root keys
- Google/OpenRouter keys
- private GPX contents

Route API logs may store coarse region/latency but should avoid exact home coordinates.

## Backups

Back up:
- community DB
- RIG DB
- route artifacts
- region manifest metadata
- configuration

Graph caches can be rebuilt; do not prioritize them over irreplaceable uploads.

## Moderation

For a few-user self-host:
- admin-only moderation page
- reports queue
- hide/restore
- block public identity
- immutable moderation audit event

No elaborate reputation system in v1.
