# 07 — Offline & Region Architecture

## Product model

Two downloadable object types:

### Region Pack
For spontaneous exploration in an area.

Capabilities can include:
- vector map tiles
- routing graph
- road intelligence
- POIs
- search index
- elevation
- official layers

### Ride Pack
For one selected ride.

Smaller:
- corridor map
- selected route + alternatives
- cues
- nearby reroute graph
- relevant RIG segment evidence
- critical POIs

The user should rarely need to understand graph internals.

# Region UX

The user can select states, but the implementation should not assume state boundaries are routing boundaries.

Example:
`Pennsylvania`

Internally a pack includes:
- PA
- a border halo sufficient to route across nearby state lines
- versioned tile set

For multi-state routes, required packs are automatically suggested.

# Server-side regional routing

GraphHopper prefers a prepared graph, so dynamically routing across independent state graphs is awkward.

Recommended self-host approach:
1. Maintain state PBF sources.
2. User chooses installed server regions.
3. Worker builds one merged **active routing territory** from selected adjacent states.
4. Build into a staging directory.
5. Health-check golden routes.
6. Atomic swap router to new graph.
7. Keep previous graph for rollback.

For Hatboro default:
`PA + NJ`
with optional NY/DE/MD later.

A self-hoster who selects distant states can create separate routing territories rather than one massive nationwide graph.

# Browser offline graph

Do not load an entire state graph into React/JS main thread.

Requirements:
- graph search in Web Worker
- tile/partition graph
- spatial index for snap
- lazy tile loading
- upper memory budget
- search state budget
- cancellation
- deterministic failure state

The current v2 router's full merge into JS Maps is suitable only for bounded packs. P28 must replace/contain this for state-scale use.

# Suggested partition

Use a regular spatial partition such as H3/S2/geohash or the existing offline tile scheme.

Each graph tile:
- border nodes
- directed edges
- turn restrictions
- compact profile features
- RIG features
- checksum/version

Routing loads a corridor of tiles around the search frontier, not every installed tile.

# Pack manifest

Every pack must advertise:

```json
{
  "id": "us-pa-2026-08-01",
  "region": "PA",
  "schemaVersion": 3,
  "osmSnapshot": "...",
  "rigVersion": "...",
  "builtAt": "...",
  "capabilities": {
    "map": true,
    "route": true,
    "reroute": true,
    "search": false,
    "poi": true,
    "elevation": true
  },
  "bytes": 123,
  "sha256": "..."
}
```

# Atomic install

Download:
`partial → checksum → schema validate → index validate → activate`

Never write directly over the active pack.

# Storage

Before download:
- call `navigator.storage.estimate()`
- show required/free space
- request persistent storage where supported
- allow automatic cleanup of stale Ride Packs
- never auto-delete a user's saved/imported GPX

# Offline readiness

A route detail page should say:

```text
Offline
Map              Ready
Turn guidance     Ready
Rerouting         Ready within 10 mi corridor
Search            Online only
Weather           Online only
```

This is far clearer than "Downloaded."

# Update cadence

State metadata can be checked daily/weekly, but graph updates should be explicit and safe.

Do not rebuild the active browser pack while navigating.

# Regional data source scope

Core:
- OSM/Geofabrik
- RIG
- optional elevation
- USFS MVUM in relevant regions

Do not bloat initial packs with every Explorer Mode layer.
