# 02 — Target Architecture

## Architectural rule

**The browser is the interaction/navigation client, not the national geospatial compute cluster.**

Heavy server-side work runs on the faster LXC. The browser keeps only the active ride, local library metadata, and explicitly installed offline packs.

## Deployable services

### `switchback-web`
Next.js PWA:
- UI
- API boundary
- auth/session for optional identity
- lightweight orchestration
- static assets

It must not perform graph imports or large GPX processing in request handlers.

### `switchback-router`
GraphHopper primary:
- legal routing
- path details
- alternatives
- round trips
- map matching where appropriate
- custom model inputs

Valhalla remains optional for:
- supplemental alternatives
- elevation
- future experiments

Never expose router ports publicly.

### `switchback-worker`
Node worker service:
- GPX ingestion
- map-match batches
- road-intelligence aggregation
- route fingerprinting
- AI description jobs
- region manifest/build jobs
- community route processing
- data migrations that are not request-time work

Use a durable job queue. For a small self-host, a SQLite-backed queue is acceptable. Redis is not required initially.

### `switchback-data`
For the initial self-host:
- SQLite in WAL mode for metadata/community/RIG indices if concurrency is modest.
- Filesystem/object directory for raw GPX, processed route artifacts, region bundles.
- Existing better-sqlite3 is acceptable.

If public usage exceeds a few dozen concurrent writers, migrate community/RIG metadata to PostgreSQL. Do not begin with Postgres unless needed.

### `switchback-region-builder`
Can initially be a worker job instead of a permanent service:
- downloads state PBFs
- normalizes motorcycle access
- merges selected server regions
- builds staging GraphHopper graph
- builds browser offline tiles
- validates checksums
- atomically swaps active graph/bundles

## Browser architecture

### Shell
`AppShell`
- owns route between high-level modes only: `explore | plan | ride | library | settings`
- no routing logic

### Session controllers
- `PlanningSessionController`
- `RideSessionController`
- `FreeRideSessionController`
- `ImportSessionController`
- `OfflineDataController`

These are domain coordinators, not React components.

### Stores
Use small scoped stores:
- `appStore`: mode, modals, sheets
- `plannerStore`: active intent/request + selected candidate ids
- `rideStore`: current navigation session
- `libraryStore`: indexes and filters only
- `mapStore`: camera, base style, active overlay ids
- `offlineStore`: pack manifest/readiness
- `identityStore`: optional sync/community session metadata

Never put large route geometries in multiple stores. Keep a canonical route entity cache keyed by id.

## Server request pattern

Browser:
`intent → /api/plan → planning coordinator → router + RIG → candidates → ranker → response`

The response should contain only the routes needed for display, not giant graph/evidence dumps.

## Worker pattern

Upload GPX:
`upload → durable object → enqueue → parse → normalize → map match → canonical segments → route metrics → RIG evidence → AI metadata → publish`

The API immediately returns an ingestion id. UI receives progress.

## Package boundaries

Recommended target folders:

```text
src/
  app/
  components/
    shell/
    explore/
    plan/
    ride/
    library/
    shared/
  domain/
    routing/
    roads/
    free-ride/
    community/
    identity/
    offline/
    navigation/
  application/
    planning/
    free-ride/
    import/
    navigation/
    region/
  infrastructure/
    graphhopper/
    valhalla/
    sqlite/
    webauthn/
    providers/
    jobs/
  workers/
  stores/
```

Do not create a second parallel architecture and leave the old one alive indefinitely. Each migration phase must delete or redirect old ownership.

## Memory ownership

One large object must have one owner.

Examples:
- MapLibre owns rendered tile data.
- `RouteEntityCache` owns active full route geometries.
- UI stores only ids/small summaries.
- Offline pack worker owns parsed graph tiles during a route calculation.
- GPX worker owns raw trace arrays during ingest.
- Region builder owns PBF/graph build memory.

## Process isolation

The router JVM gets a defined heap.
The worker gets a defined Node heap.
The web process gets a small Node heap and is restarted independently.
Region builds are never performed inside the running router process.

This is central to making the LXC architecture reliable.
