# 10 — Data Providers & Budget

**Budget target:** approximately $10/month for the primary self-host.

Pricing and free quotas change. Treat these as deployment-time choices and re-check before release.

## Recommended default stack

### Routing
**Self-host GraphHopper** — primary.

Reason:
- already integrated
- open-source Apache-2.0
- motorcycle support
- map matching
- path details
- alternatives
- custom models
- no per-request fee on self-host

The commercial GraphHopper Directions API currently has a free entry option but paid tiers are far above the target budget; do not make hosted GraphHopper a production dependency.

### Optional router/elevation
Valhalla self-hosted.

Keep optional.

### Basemap
**OpenFreeMap + MapLibre**.

As of 2026-08-10 OpenFreeMap states that its public instance is free with no map-view/request limit, registration, API key, or cookies. Still retain self-hostable tile/style configuration so a public service policy change cannot break Switchback.

### Place/address search
**Google Places only as an optional quality enhancer**, Photon/self-hosted Photon fallback.

As of 2026-08-10 Google's current pricing page lists 10,000 free monthly requests for several Essentials SKUs including Autocomplete Requests, Geocoding, and Place Details Essentials. Use field masks and IDs-only calls where appropriate.

Rules:
- server-side API key
- hard quota/budget alert
- cache only where provider terms permit
- Photon path always available
- never use Google routing as the recreational route engine

### Weather
National Weather Service for US deployments.

No paid weather service required initially.

### Elevation
USGS 3DEP-derived preprocessing for US regions where practical.

Do not call an elevation API for every route if the data can be precomputed into segment features.

### ADV legality / public motorized roads
US Forest Service MVUM datasets.

MVUM is high-value because it contains designated motor-vehicle roads/trails and seasonal/vehicle-class data. Treat it as official designation evidence for applicable National Forest System routes, with source date/provenance.

### Traffic signals
OSM `highway=traffic_signals`.

Useful for route flow/stop-density and Explorer Mode. Not live timing.

### Live traffic
**Defer paid live traffic.**

The $10 budget is better spent on search quality. Road class, intersection/signal density, urbanity, route history, and community road evidence are adequate proxies for recreational routing v1.

### Mapbox
Optional Explorer Mode enhancement only.

Do not make Mapbox required. Current Mapbox search has a free tier, and its ecosystem can provide attractive 3D/terrain experiences, but OpenFreeMap/MapLibre should remain the default.

## Cost guardrails

Environment:
```text
SWITCHBACK_MONTHLY_EXTERNAL_BUDGET_USD=10
```

Track external calls:
- provider
- SKU/operation
- count
- estimated spend
- cache hit

Diagnostics page:
`Estimated provider spend this month: $X.XX`

Kill switches:
- Google Places
- external AI
- optional imagery/3D provider
- web research

Never allow an optional enrichment outage/quota to break routing/navigation.
