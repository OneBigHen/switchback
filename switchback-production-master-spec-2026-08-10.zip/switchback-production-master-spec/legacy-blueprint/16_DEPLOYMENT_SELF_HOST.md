# 16 — Deployment & Self-Host

## Goal

A competent homelab user should go from zero to a PA/NJ instance without manually reverse-engineering the repo.

Target:

```bash
git clone ...
cp .env.example .env
docker compose up -d
```

Then web setup wizard.

# Compose services

Recommended:
- `web`
- `worker`
- `router`
- `caddy` (optional if external proxy already exists)

Optional:
- `valhalla`

Volumes:
- `/data/app`
- `/data/routes`
- `/data/regions`
- `/data/router`
- `/data/backups`

# Setup wizard

First boot:
1. Admin passkey / local admin token
2. Choose home routing territory
3. Choose state data
4. Optional providers
5. Build/import status
6. Golden-route validation
7. Ready

Default recommendation for owner:
`Pennsylvania + New Jersey`

# Region build

Never block web process.

Wizard shows:
- downloading
- normalizing OSM
- importing
- building offline packs
- validating
- activating

Resume after failure.

# Configuration

Provider settings:
- Google Places key
- AI provider/key/model
- optional Valhalla endpoint
- map style
- NWS user agent
- community enabled
- max upload size
- external API monthly budget

# Health

`/api/health` should return:
- web
- database
- worker queue
- GraphHopper
- active graph version
- region manifest version
- optional provider states

No secrets.

# Upgrades

Database migrations are:
- versioned
- backward compatible for one release where practical
- backed up before destructive migration

Region bundles/schema have independent versions.

# Rollback

Keep:
- previous web image
- previous DB backup
- previous active router graph
- previous region manifest

A failed new graph cannot take the active router offline.

# LXC

For the existing faster LXC:
- router and worker can run there
- assign explicit RAM
- graph import serialized
- Next.js web can run same LXC initially but separate process/container
- do not let graph import OOM-kill navigation service
