# 03 — Road Intelligence Algorithm

## Decision: this is not a RAG problem

The original idea—learn useful pieces of road from ~100 vetted GPX routes and connect them into new rides—is excellent.

The correct primitive is **a spatial road graph with segment evidence**, not a vector database deciding where to route.

Use RAG later for:
- "find routes like Rick's PA-NY loop"
- semantic search over route descriptions/notes
- summarizing community comments
- converting natural language into structured intent

The core route intelligence must remain deterministic and inspectable.

# Road Intelligence Graph (RIG)

The RIG overlays evidence on the routing graph.

## Canonical segment

A segment is a directed road interval between routing-relevant junctions.

Suggested stable identity:

```text
segment_uid =
  hash(
    osm_way_id,
    from_routing_node,
    to_routing_node,
    normalized_direction
  )
```

Store an OSM snapshot/version separately.

When OSM updates:
1. prefer same OSM way + junction endpoints
2. otherwise remap old→new by geometry overlap and direction
3. retain an evidence lineage table
4. never silently discard community evidence

## Three evidence layers

### 1. Intrinsic road features
Derived from OSM / elevation / official layers:
- road class
- surface
- smoothness
- track type
- lanes
- speed limit
- access
- motorcycle access
- seasonal access
- bridge/tunnel
- curvature
- curve density/severity
- grade/elevation variation
- traffic-signal density
- stop/intersection density
- urban density
- proximity to water/parks/public lands
- official MVUM designation where available
- data age / source provenance

### 2. Community evidence
Derived from GPX and explicit reports:
- unique routes using segment
- unique contributors using segment
- recency
- repeat use by same rider
- route ratings if introduced later
- positive notes
- negative/access notes
- route role: primary interesting section vs connector
- contiguous length shared with a known-good route
- source route quality/confidence
- observed GPS trace confidence

**Important:** a GPX traversal proves only that somebody recorded/shared a traversal at some point. It does not prove legality, current access, safety, or current surface.

### 3. Personal evidence
Local/private unless sync is enabled:
- ridden count
- accepted Free Ride suggestions
- rejected suggestions
- deliberate detours toward a segment
- route selections
- "more/less like this"
- bike used
- daylight/weather context
- recency

## GPX ingestion pipeline

### Step 1 — Parse
Support:
- GPX track
- GPX route
- waypoints
- multiple segments
- timestamps when present

### Step 2 — Clean
Remove:
- impossible coordinates
- duplicate points
- stationary jitter
- obvious teleports
- sections with huge time gaps if timestamps indicate separate sessions

Keep the original file immutable.

### Step 3 — Map match
Map-match chunks to the current motorcycle graph.

Each matched segment receives:
- `segment_uid`
- match confidence
- covered distance
- traversal direction

Uncertain spans are retained as unknown geometry but **do not update RIG road evidence**.

### Step 4 — Fingerprint route
Create a route fingerprint from the ordered canonical segment ids after removing very short connector noise.

Use this to detect:
- exact duplicate uploads
- near duplicate routes
- same route with minor edits

### Step 5 — Attribution
A route contributes at most a bounded amount of evidence to a road.

Do not allow someone to upload the same GPX 100 times and make a road appear 100× more popular.

Recommended effective contribution:

```text
uploader_route_weight = min(1.0, route_quality_confidence)
duplicate_family_weight = 1 / max(1, near_duplicate_count_for_uploader)
match_weight = map_match_confidence
effective_positive = uploader_route_weight
                   * duplicate_family_weight
                   * match_weight
```

Cap each uploader's positive evidence per segment.

### Step 6 — Determine route role
Not every road inside a good GPX is a "good road." Some are necessary connectors.

Estimate a segment's route role using:
- road interest prior
- contiguous run length
- deviation from direct baseline
- whether segment lies in a high-interest cluster
- local curvature/surface/elevation
- whether many independent routes repeatedly choose it despite a faster parallel connector

Classify:
- `highlight`
- `supporting`
- `connector`
- `unknown`

Only `highlight` and `supporting` should strongly increase recreational desirability.

# Community confidence

Keep **desirability** and **confidence** separate.

Example positive evidence strength:

```text
independent_strength =
  sum(min(1, source_weight)) across unique contributors

evidence_strength =
  1 - exp(-independent_strength / 3)
```

This gives rapid gains from the first few independent sources, then diminishing returns.

Example community interest:

```text
community_interest =
  prior_interest * (1 - evidence_strength)
  + observed_interest * evidence_strength
```

Negative/access reports are not simply subtracted from "fun". They produce:
- a routing warning
- a confidence reduction
- or a hard eligibility block if an authoritative closure/access source confirms it

# Segment desirability vectors

Do not reduce a road to a single permanent score.

Store dimensions:

```text
twisty_interest
scenic_interest
adv_interest
gravel_interest
paved_touring_interest
remoteness
flow
elevation_interest
community_interest
novelty
data_confidence
access_confidence
```

Bike/ride intent supplies weights.

# Eligibility

Eligibility executes **before** scoring.

Hard reject when supported by current evidence:
- forbidden/private motorcycle access
- active authoritative closure
- incompatible vehicle class
- explicit rider avoid-area
- required surface/difficulty violated
- route request hard constraint impossible

Soft warning/penalty:
- unknown surface
- stale data
- conditional access
- low confidence
- seasonal uncertainty
- possible roughness mismatch

Never hard reject merely because community evidence is missing.

# Route candidate generation

Scoring a single GraphHopper route is not enough. Switchback must deliberately generate diverse candidate corridors.

## A-to-B candidates

Generate:
1. direct baseline
2. router-native alternative(s)
3. interest-anchor candidates
4. community-corridor candidate
5. gravel/ADV corridor candidate
6. scenic/terrain corridor candidate when requested

### Interest anchors

Build a feasible ellipse/corridor around origin→destination using the maximum detour/time budget.

Inside it:
- query high-value RIG clusters
- cluster contiguous segments
- select 1–3 anchor coordinates
- request legal routes through those anchors

Avoid random waypoint spam.

## Loop candidates

Use:
- 8–16 heading sectors
- several target radii derived from requested duration
- RIG cluster anchors
- loop native router seeds
- user road preferences
- route overlap rejection

Generate broadly; rank later.

# Route utility

A route score is the distance-weighted utility of segments plus route-level structure.

Illustrative model:

```text
segment_utility =
    w_adv       * adv_interest
  + w_gravel    * gravel_interest
  + w_twisty    * twisty_interest
  + w_scenic    * scenic_interest
  + w_elevation * elevation_interest
  + w_flow      * flow
  + w_community * community_interest
  + w_novelty   * novelty
  - w_highway   * highway_penalty
  - w_urban     * urban_stop_penalty
  - w_uncertain * uncertainty

route_utility =
    length_weighted(segment_utility)
  + contiguous_high_quality_bonus
  + corridor_coherence_bonus
  + preference_fit
  - backtrack_penalty
  - self_overlap_penalty
  - detour_penalty
  - fragmentation_penalty
```

## Why contiguous bonus matters

Ten separate 0.2-mile gravel snippets are not equal to one flowing 12-mile gravel road.

Reward contiguous runs:
- good curves
- gravel
- low-stop backroads
- known community corridors

This is where the "piece-meal" concept becomes good riding instead of statistical confetti.

# Diversity selection

After eligibility and score, choose three routes using maximal marginal relevance:

```text
selection_score =
  lambda * normalized_utility
  - (1 - lambda) * max_overlap_with_already_selected
```

Suggested `lambda ≈ 0.72`.

Reject near-duplicates above an overlap threshold unless they differ materially in surface or road character.

# Personal learning

V1 does **not** require a neural model.

Use transparent signed preference updates:
- accepted suggestion → small positive update
- "more like this" → stronger positive update
- ignored suggestion → tiny/no negative update (could be timing)
- "less like this" → explicit negative
- route selected over alternatives → pairwise weak preference
- route abandoned is ambiguous; do not assume dislike

Use exponential decay so ancient behavior does not dominate.

Separate model per stable bike id.

Later, after sufficient real rides, a small pairwise ranking model can replace hand-tuned preference updates while preserving eligibility gates.

# Golden-road validation

Before shipping route intelligence:
- build a hand-reviewed PA corpus around Hatboro, New Hope, Jim Thorpe, Poconos, central PA, state forest/gravel areas
- include known good and intentionally bad connectors
- assert rank order, not exact score
- run after every weight/feature change

The algorithm is production-ready only when it consistently improves known riding routes without making obviously irrational detours.
