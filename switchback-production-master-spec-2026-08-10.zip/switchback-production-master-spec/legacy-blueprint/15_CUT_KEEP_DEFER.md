# 15 — Keep / Rewrite / Cut / Defer

| Surface | Decision | Reason |
|---|---|---|
| GraphHopper primary | KEEP | Strong existing base |
| Valhalla | KEEP OPTIONAL | Useful supplemental provider |
| MapLibre | KEEP | Correct PWA map renderer |
| OpenFreeMap | KEEP DEFAULT | Low-cost/open default |
| Google Places | KEEP OPTIONAL | Search quality |
| Photon | KEEP | Fallback/self-host path |
| NWS | KEEP | US weather |
| Current route comparison concept | REWRITE UX | Good capability, poor exposure |
| Current route score | REWRITE | Separate eligibility/confidence/utility/diversity |
| Current Free Ride candidate source | REWRITE | Must be graph/RIG backed |
| Current Free Ride gating | KEEP/REFINE | Useful groundwork |
| Road locks | KEEP ADVANCED | Good expert control |
| Sketch route | KEEP ADVANCED | Valuable expert tool |
| Avoid areas | KEEP ADVANCED | Valuable |
| Bike profiles | KEEP/UNIFY | Central to ADV/street behavior |
| GPX import/export | KEEP/EXPAND | Core ecosystem requirement |
| Local library | KEEP | Local-first |
| Recording/replay | KEEP | Valuable evidence/history |
| Offline v2 | REWORK | Worker/partition/memory needed |
| Region manager | REWORK | Productize capabilities |
| Explorer layers | KEEP OPTIONAL | "God Mode" |
| Curvature overlay | KEEP OPTIONAL | Valuable evidence |
| PA DEP legacy unpaved data | KEEP ONLY WITH PROVENANCE | Old source; never access authority |
| USFS MVUM | ADD | High-value ADV legal designation |
| Road Intelligence Graph | ADD | Core differentiator |
| Community route DB | ADD | Route-centered community |
| Passkey identity | ADD OPTIONAL | No-password ownership |
| Encrypted sync | ADD OPTIONAL | Cross-device without mandatory cloud account |
| Spotify | CUT FROM CORE | Unrelated complexity |
| Spotify provider seam | KEEP EMPTY | Easy future plugin |
| Static scenic gallery | CUT | Not route evidence |
| "Neural" top-level profile | CUT | Personalization is ranking policy |
| Avoid-highway top-level profile | CUT | Ride option |
| Gravel top-level engine profile | CUT | Surface policy/intent; can remain user-facing label where useful |
| Social feed | DEFER | Scope creep |
| Forum/clubs/messages | DEFER | Scope creep |
| Paid live traffic | DEFER | Budget/ROI |
| Native app | DEFER | PWA first |
| CarPlay/Android Auto | DEFER | Native dependency |
| ML pairwise ranker | DEFER | Need real data first |
| Nationwide preinstall | CUT | Region/territory model |
