# 17 — Data Model & API Contracts

This is a target contract, not a mandate to rename everything in one PR.

# Core route entities

## `RideIntent`
Human intent after validation.

## `RoutingRequest`
Provider-neutral deterministic request.

## `CandidateRoute`
Raw eligible route candidate + segment metrics.

## `RankedRoute`
Candidate + utility + explanation + diversity role.

## `RideSession`
Navigation lifecycle.

# Road intelligence

## `RoadSegment`
Canonical geometry/topology identity.

## `RoadSegmentIntrinsic`
OSM/elevation/official features.

## `RoadEvidenceEvent`
Append-only evidence from:
- GPX traversal
- community note
- explicit rider feedback
- official dataset update

## `RoadSegmentAggregate`
Materialized/derived current score dimensions.

Never make the aggregate the only source; retain events for recomputation.

# Community

## Route publication
- `community_route`
- `community_route_revision`
- `community_route_artifact`
- `community_route_segment`
- `community_note`
- `community_comment`

# API sketches

## `POST /api/plan`
Input:
- RideIntent / RoutingRequest
Output:
- planning id
- candidate summaries
- selected recommendation id
- structured explanation
- evidence version

## `POST /api/free-ride/evaluate`
Input:
- coarse session context
- current segment/position/heading
- preference summary
Output:
- zero or one suggestion

Do not send full ride history each poll.

## `POST /api/imports`
Multipart GPX.
Returns ingest id.

## `GET /api/imports/:id`
Progress + processed route id.

## `POST /api/community/routes`
Publish processed route revision.

## `GET /api/community/routes`
Spatial/filter query:
- bbox / near
- ride type
- surface
- duration/distance
- difficulty

## `POST /api/sync/blobs`
Encrypted opaque payload only.

# Versioning

Every persistent/public contract has:
- schema version
- migration
- validation

Do not rely on TypeScript types as runtime validation.
