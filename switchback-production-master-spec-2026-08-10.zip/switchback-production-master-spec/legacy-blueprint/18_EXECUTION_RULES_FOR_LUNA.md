# 18 — Execution Rules for Luna / Lower-Cost Coding Models

This file exists because implementation will be delegated to a model that may optimize for speed instead of correctness.

## Mandatory behavior

Before editing:
1. Read the phase file completely.
2. Inspect every file named in "Likely touch points."
3. Inspect existing tests for that subsystem.
4. State the actual current behavior in the worklog.
5. Make the smallest coherent architecture change that reaches the phase gate.

After editing:
1. lint
2. typecheck
3. targeted unit tests
4. full unit suite
5. relevant Playwright suite
6. build
7. phase-specific benchmark/soak
8. update traceability/worklog

## Never do these

- Do not create placeholder implementations and mark phase done.
- Do not add TODO-only interfaces to satisfy types.
- Do not hard-code fake scenic/safety/access/confidence values.
- Do not catch every error and return a fake success.
- Do not duplicate stores to avoid refactoring.
- Do not create a second route scoring system and leave the first active.
- Do not put server secrets into `NEXT_PUBLIC_*`.
- Do not weaken tests merely to make CI pass.
- Do not skip real router tests after routing changes.
- Do not call something "offline ready" if rerouting/search is unavailable.
- Do not mark a GPX road "verified" because a user uploaded it.
- Do not use AI output as legal routing geometry.
- Do not let Explorer Mode code load by default if the layer is disabled.
- Do not change public behavior outside phase scope without documenting it.

## Phase commit discipline

One phase can use several commits, but it must end with:
- green gate
- no dead compatibility path unless explicitly scheduled for the next phase
- migration notes
- measurable evidence

## Required phase report

```text
Phase:
Before:
After:
Files changed:
Deleted:
Tests added/changed:
Commands run:
Results:
Performance/memory evidence:
Known limitations:
Next phase dependencies:
```

## Cut rule

If a phase expands by >30% because of a nice-to-have:
- stop
- document it in `DEFERRED.md`
- complete the original gate

Shipping the product is more important than polishing optional architecture.
