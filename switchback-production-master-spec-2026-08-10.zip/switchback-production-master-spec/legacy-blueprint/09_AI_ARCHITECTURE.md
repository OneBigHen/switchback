# 09 — AI Architecture

## AI responsibilities

AI may:
- parse natural-language ride requests
- resolve ambiguity conversationally
- summarize structured route data
- compare routes
- describe imported/community GPX
- extract structured facts from rider-written notes
- semantic-search route descriptions/comments
- suggest modifications
- explain why a route was recommended

AI must not:
- invent road legality
- invent surface
- create unvalidated route geometry
- override authoritative closure/access data
- declare a route safe
- silently change rider constraints

# Intent contract

LLM output is a versioned JSON intent object validated with a strict schema.

Example:

```json
{
  "mode": "loop",
  "origin": {"kind": "current"},
  "targetMinutes": 180,
  "bikeId": "dual-sport-1",
  "surface": {
    "gravel": "prefer",
    "dirt": "allow",
    "rough": "avoid"
  },
  "roadCharacter": {
    "twisty": 0.7,
    "scenic": 0.6,
    "remote": 0.5
  },
  "avoid": ["highways", "PA-611"],
  "stops": [
    {"category": "lunch", "position": "midpoint"}
  ],
  "confidence": 0.92,
  "ambiguities": []
}
```

Validation layer clamps values and rejects unknown fields.

# Deterministic fallback

Keep a local parser for:
- addresses
- destinations
- loop duration
- basic style
- avoid highways
- stops

If AI fails, core routing still works.

# Provider abstraction

`RideLanguageProvider`:
- `interpretIntent`
- `describeRoute`
- `compareRoutes`
- `summarizeCommunity`
- `extractNoteSignals`

Implement:
- optional OpenRouter
- future local model adapter
- disabled/no-AI adapter

No UI imports provider SDKs directly.

# Cost control

AI calls are never in the GPS loop.

Cache by:
- structured route fingerprint
- model id
- prompt schema version
- language

Community route description is generated once at ingest and regenerated only when material route metadata changes.

# GPX description grounding

Prompt input includes only validated structured facts:
- regions
- distance
- surface mix
- elevation
- route geometry stats
- official data overlap
- community notes
- POIs/fuel
- data confidence

Required output:
- short summary
- who it suits
- notable characteristics
- cautions/unknowns
- tags

The model must surface unknowns instead of filling them.

# RAG

Use RAG only for text retrieval:
- route descriptions
- notes
- comments
- rider's own saved-route metadata

Spatial query occurs first:
`near me / intersects viewport / within feasible ride area`

Then semantic ranking occurs within that geographically relevant set.

This avoids embedding 100,000 road segments and asking a language model to solve topology.

# Prompt injection

Community text is untrusted input.

Never concatenate comments into a system prompt and allow them to instruct tools.

Wrap community content as data, not instructions.
