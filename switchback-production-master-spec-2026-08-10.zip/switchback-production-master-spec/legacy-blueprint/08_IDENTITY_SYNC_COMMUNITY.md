# 08 — Identity, Sync & Community

## Goal

Preserve the no-account experience while enabling:
- cross-device sync
- ownership of public route uploads
- comments/notes
- basic moderation

## Decision

Use **three levels**, not one mandatory account.

### Level 0 — Local Rider
Default.
- no account
- no server identity
- plan/ride/import/export/save locally
- can browse public community routes

### Level 1 — Switchback ID
Optional pseudonymous identity.
- no email/password
- display name optional
- WebAuthn/passkey credential
- enables public uploads/comments
- server stores public identity id and credential public key

### Level 2 — Private Sync
Optional end-to-end encrypted sync associated with Switchback ID or a device-link key.
- settings
- saved/private routes
- bikes
- preference model
- library metadata

Public community objects are not encrypted because they are intentionally public.

# Why WebAuthn/passkeys

Better than inventing our own signing crypto UX:
- phishing-resistant
- no passwords
- platform-native
- iCloud/Google password managers may sync passkeys
- server does not hold a reusable password secret

Still offer a device-link method because passkey availability/sync is not universal.

# Device link

On an already trusted device:
`Settings → Sync → Link device`

Generate:
- one-time short-lived pairing session
- QR code

New device scans QR.
The two clients exchange an encrypted sync-root package through a server relay.

Requirements:
- pairing expires ≤10 minutes
- one-time use
- authenticated by existing session on source
- sync root never logged
- server sees ciphertext only

If implementing secure pairing becomes too large for first production, ship passkey identity + encrypted backup file first and defer live QR pairing. Do not ship home-grown weak crypto.

# Private sync encryption

Use browser-supported WebCrypto:
- AES-GCM 256
- random 96-bit nonce per blob
- HKDF-derived per-object keys from a random 256-bit sync root
- versioned envelope
- authenticated metadata

Server stores opaque encrypted blobs.

Do not encrypt public route geometry using the private sync system.

# Community database

Objects:
- identity
- route
- route_revision
- route_artifact
- route_note
- comment
- reaction/favorite (optional)
- report
- moderation_action

No forum post object.

# Upload process

Public upload:
1. user chooses a local/imported/recorded route
2. visibility confirmation
3. privacy-zone redaction if enabled
4. upload original/derived GPX artifact
5. worker ingests/maps it
6. AI creates draft title/description/tags from structured route facts
7. uploader reviews description
8. publish

Never auto-publish an AI description without giving uploader a review screen.

# Privacy zones

Default optional home privacy:
- remove start/end geometry around configured private locations
- redact street/instruction metadata in same area
- rebase displayed distance/time correctly
- do not expose raw private trace through downloads/API

Community route processing must occur on the redacted version if privacy is enabled.

# Comments

Keep simple:
- route-level comments
- optional route-point/segment note later

Rate limits:
- per identity
- per IP
- content length
- duplicate spam
- link count

No DMs.

# Moderation

Small-community first:
- route owner can hide comments on own route
- report comment/route
- admin moderation page
- soft-delete/tombstone
- audit log

Do not build algorithmic content moderation infrastructure before needed.

# Community trust

Do not call someone "verified rider."

Evidence dimensions:
- uploader age
- independent uploads
- successful map-match
- route duplicate family
- number of independent contributors to segments
- notes/reports

A public GPX contributes to road-interest evidence, but not legal/safety authority.
