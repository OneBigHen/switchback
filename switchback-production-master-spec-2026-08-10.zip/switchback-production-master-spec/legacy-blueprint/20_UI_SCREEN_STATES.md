# 20 — UI Screen / State Specification

## Navigation model

Persistent high-level modes:
- Explore
- Plan (only when a plan exists)
- Ride (only active session)
- Library
- Settings (secondary)

No hamburger mega-menu on mobile.

# Explore states

## E0 — Idle
Map + search + bottom actions.

## E1 — Search expanded
Full sheet, keyboard, recents, suggestions.

## E2 — Intent parsing
Inline spinner in search field. Map remains usable.

## E3 — Intent confirmation
Compact structured chips + Plan.

## E4 — Planning
Previous map stays visible.
Bottom progress:
`Finding good roads · 4s`
Cancel available.

## E5 — Error
Actionable:
- location
- coverage
- router
- search
- constraint impossible

# Plan states

## P0 — Candidate choice
2–3 candidate cards.

## P1 — Why route
Evidence breakdown.

## P2 — Customize
Expert settings.

## P3 — Edit map
Map manipulation mode.

## P4 — Prepare
Start / Download / Export / Save.

# Ride states

## R0 — GPS acquiring
Route preview visible.

## R1 — On route
Main HUD.

## R2 — Uncertain
Navigation cue de-emphasized.

## R3 — Deviating
No immediate reroute.

## R4 — Off route
Rejoin/replan choices.

## R5 — Free Ride suggestion
Temporary banner.

## R6 — Offline degradation
Capability-specific badge.

## R7 — Arrival
Save ride / continue Free Ride / end.

# GPX states

## G0 — Import picker
## G1 — Processing
## G2 — Analysis
## G3 — Entry selection
## G4 — Approach
## G5 — GPX guidance
## G6 — Track-only unmatched span

# Library states

## L0 — Mine
## L1 — Community
## L2 — Community map
## L3 — Route detail
## L4 — Publish/review
## L5 — Comment/report

# Settings

Only important default settings:
- Bike
- Navigation voice
- Units
- Offline data
- Sync/identity
- Explorer Mode
- Providers (admin/self-host)
- Diagnostics

Do not expose developer/provider health in normal ride settings.
