# 04 — Free Ride Engine

Free Ride is the main differentiation. Treat it as a product of its own.

## User promise

Tap **Just Ride** and go.

Switchback should not demand a destination. It should quietly help the rider discover worthwhile roads ahead without turning the ride into notification spam.

## Current concepts worth keeping

The existing implementation already has good safety/product mechanics:
- GPS-confidence gate
- workload gate
- direction-aware suppression
- expiry
- cooldown
- explicit accept/ignore
- fragment traversal validation

Keep those concepts. Replace candidate generation and tune interruption policy.

# Free Ride session state

```text
idle
arming
riding
suggestion-ready
suggestion-shown
suggestion-accepted
replanning
quiet-period
paused
ended
```

Transitions must be deterministic and testable.

# Context window

Maintain a compact rolling context:
- last ~90 seconds of GPS
- stable heading
- speed
- road match
- recent road segment ids
- last accepted/rejected suggestions
- current bike profile
- remaining user time if set
- home/base coordinate if user chose one
- daylight/weather snapshots when online
- installed offline capability

Do not retain the entire ride in React state.

# Candidate horizon

Dynamic by speed:

```text
< 25 mph: 3–6 mi
25–45 mph: 5–10 mi
45–65 mph: 8–16 mi
> 65 mph: 12–22 mi
```

The horizon should be a **reachable graph horizon**, not a circle.

# Ahead cone

Prefer candidates whose first decision point lies generally ahead.

Heading filter:
- normal: ±70°
- exploratory mode: ±100°
- never require an unexpected U-turn unless user explicitly asks to turn around

Use road-network path direction, not merely straight-line bearing.

# Candidate classes

### Interesting branch
A highly rated road leaves the current corridor and rejoins later.

### Better continuation
At a fork, one branch is substantially more interesting while remaining directionally sensible.

### Mini-loop
A short loop returns to the rider's general progression.

### Gravel opportunity
A legal/compatible gravel or unpaved corridor is nearby.

### Scenic opportunity
High-interest scenic/elevation corridor.

### Community road
A segment cluster has strong independent community evidence.

### Stop
Fuel/food/overlook only when relevant and requested/enabled.

# Candidate construction

1. Identify decision nodes reachable in the next horizon.
2. From each decision node, query high-interest RIG clusters.
3. Construct a legal route fragment through the cluster.
4. Require a plausible exit/rejoin or meaningful onward direction.
5. Compute added time/distance relative to staying on the current local trajectory.
6. Apply hard constraints.
7. Rank.
8. Apply interruption threshold.

No synthetic road attributes.

# Free Ride score

```text
free_ride_value =
    road_interest_gain
  + community_evidence
  + rider_preference_fit
  + novelty
  + directional_fit
  + continuity
  - detour_cost
  - turn_complexity
  - uncertainty
  - interruption_cost
  - recent_similarity
```

## Interruption cost

This is critical.

Increase interruption cost when:
- recent suggestion < 5 minutes ago
- near a complex junction
- high speed
- GPS uncertain
- active navigation instruction is imminent
- weather alert active
- rider recently ignored suggestions
- screen is locked/backgrounded and voice prompt would be intrusive

Decrease when:
- rider explicitly chose "Show me more"
- long boring connector
- exceptional candidate
- user approaches a known high-value road
- ride timer indicates it's time to turn home

# Default suggestion frequency

Do **not** use a 30-second user-facing cooldown.

Initial production default:
- maximum one unsolicited suggestion every **5 minutes**
- target normal rate: 1–3 suggestions/hour
- exceptional threshold may override once
- after two ignored suggestions: quiet for 20 minutes
- "More ideas" manually requests immediate reevaluation

Internally candidates can refresh much more often.

# UX

Collapsed chip:
`Great gravel road ahead · +12 min`

Tap/voice expansion:
- road/corridor name
- why
- extra time
- surface evidence
- confidence/source
- Accept / Not now / Less like this

If accepted:
- lock the recommended fragment as a temporary Must corridor
- route through it
- validate actual traversal
- if router cannot honor it, say so and do not pretend success

# Free Ride modes

Keep simple defaults:
- **Explore** — balanced recreational discovery
- **Gravel Hunt** — prioritize legal gravel/unpaved
- **Twisties**
- **Scenic**
- **Head Home** — use remaining time and location to gradually bias home

Do not expose these as a giant mode menu on the home screen. Bike defaults pick the normal behavior.

# Offline Free Ride

When an offline graph + RIG slice exists:
- Free Ride continues using local features/evidence
- no live weather/closures/community updates
- UI marks data timestamp
- suggestions requiring missing capability are suppressed

# Acceptance tests

Free Ride does not ship as non-experimental until:
- 100% candidate road attributes come from real graph/evidence sources
- no candidate behind rider in directional fixtures
- accepted suggestion route covers ≥80% of intended highlighted corridor where geometrically possible
- 60-minute simulated drive produces no more than configured unsolicited cap
- duplicate suggestion suppression works after reroutes
- low GPS confidence suppresses prompts
- intentional route deviation is not treated as an error loop
- memory remains bounded over a 2-hour simulated ride
