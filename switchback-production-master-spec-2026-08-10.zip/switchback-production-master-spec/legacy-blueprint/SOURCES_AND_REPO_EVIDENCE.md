# Sources and Repository Evidence

## Repository evidence used for this blueprint

From current `OneBigHen/switchback`:
- `package.json`: Next 16, React 19, MapLibre, Dexie, Zustand, Vitest, Playwright, QA scripts, offline build scripts.
- `README.md`: GraphHopper-primary hybrid routing, timeboxed loops, GPX, local IndexedDB, weather, ride guidance, offline work.
- `src/components/planner/PlannerShell.tsx`: broad orchestration ownership remains concentrated.
- `src/components/planner/PlannerDeck.tsx`: many planner/expert capabilities share one UI surface.
- `src/lib/domain/contracts.ts`: provider-neutral road/route contracts already exist.
- `src/lib/recommendation/route-score.ts`: current weighted score.
- `src/lib/recommendation/free-ride.ts`: direction, GPS/workload gates, expiry, cooldown, traversal validation.
- `src/lib/domain/feature-flags.ts`: Free Ride remains explicitly described as needing graph-backed candidates.
- `src/lib/offline/v2-router.ts`: current in-browser offline graph search.
- `public/sw.js`: bounded separated caches now exist.
- prior repo recovery audit: original PlannerShell god-component, synthetic Free Ride attributes, offline/service-worker defects and feature disposition.

## Current external source assumptions checked 2026-08-10

- GraphHopper open-source engine is Apache-2.0 and supports OSM routing, motorcycle profiles, map matching, path details, alternatives, custom models.
- GraphHopper commercial API pricing is not suitable as the primary dependency for a ~$10/month target; self-host remains preferred.
- Google Maps Platform current pricing publishes monthly free usage caps for multiple Essentials mapping/Places operations, including 10,000 for several search/geocoding SKUs. Exact SKU use must be rechecked before production.
- OpenFreeMap currently states public map usage is free with no map-view/request limit and can also be self-hosted.
- US Forest Service MVUM data represents designated roads/trails for motorized use and includes vehicle/season information. It is strong official evidence in National Forest contexts.
- USGS 3DEP provides national elevation datasets suitable for preprocessing elevation features.

Do not bake provider pricing into product correctness. Every external provider remains optional/degradable.
