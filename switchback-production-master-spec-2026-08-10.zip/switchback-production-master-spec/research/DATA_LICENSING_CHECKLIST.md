# Data Licensing / Attribution Checklist

Before public distribution of packs:

## OpenStreetMap / ODbL
- preserve required attribution
- document OSM source date
- review whether RIG/derived database distribution triggers database obligations
- include appropriate attribution in app/map
- do not imply OSM endorsement

## OpenFreeMap / OpenMapTiles
- verify current usage terms
- preserve upstream attributions
- retain provider abstraction

## USFS MVUM
- record dataset update timestamp
- display that designation does not guarantee physical passability
- do not claim complete current closure coverage

## Google
- do not cache/store Places data beyond allowed terms
- use required attribution where applicable
- do not bake restricted provider output into open region packs without legal review

## Community GPX
Uploader confirms:
- they have right to publish
- privacy trim reviewed
- provenance selected

## AI
Do not send private GPX/coordinates to cloud provider without explicit configured behavior and privacy documentation.
