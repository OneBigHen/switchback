# Current Research Notes — Recheck Before Release

The deep research pass used authoritative/project sources for these decisions.

Recheck current versions/pricing/terms before release.

- GraphHopper: https://github.com/graphhopper/graphhopper
- GraphHopper map matching: https://github.com/graphhopper/map-matching
- Valhalla Meili: https://valhalla.github.io/valhalla/meili/
- Valhalla dynamic costing: https://valhalla.github.io/valhalla/sif/
- OSRM API: https://project-osrm.org/docs/v5.24.0/api/
- MapLibre: https://maplibre.org/maplibre-gl-js/docs/
- OpenFreeMap: https://openfreemap.org/
- OpenMapTiles: https://openmaptiles.org/docs/
- OSM license/attribution: https://www.openstreetmap.org/copyright
- USFS MVUM: https://data.fs.usda.gov/geodata/edw/datasets.php
- WebAuthn: https://www.w3.org/TR/webauthn-3/
- WebCrypto: https://www.w3.org/TR/WebCryptoAPI/
- MDN Service Workers / Storage / IndexedDB references
- Dexie schema/version docs: https://dexie.org/docs/
- Google Maps Platform pricing: https://developers.google.com/maps/billing-and-pricing/pricing

Important licensing rule:
OSM-derived datasets and attribution obligations must be reviewed before distributing derived region/RIG products. Do not assume "open source" means "no attribution/share-alike/data-license obligations."
