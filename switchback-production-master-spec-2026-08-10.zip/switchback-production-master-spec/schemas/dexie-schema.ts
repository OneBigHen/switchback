import Dexie, { type Table } from "dexie";

export interface LocalRoute {
  id: string;
  kind: "saved" | "imported" | "recorded" | "draft";
  currentRevisionId: string;
  title: string;
  updatedAt: string;
}

export interface RouteRevision {
  id: string;
  routeId: string;
  contentHash: string;
  summary: unknown;
  blobId: string;
  createdAt: string;
}

export interface BlobRecord {
  id: string;
  contentHash: string;
  kind: string;
  data: Blob;
  bytes: number;
}

export interface TrackChunk {
  rideId: string;
  sequence: number;
  points: ArrayBuffer;
  startAt: string;
  endAt: string;
}

export interface PackRecord {
  id: string;
  buildId: string;
  kind: "region" | "ride";
  status: "partial" | "verifying" | "ready" | "stale" | "failed";
  manifest: unknown;
  installedAt?: string;
}

export interface PackChunk {
  hash: string;
  packId: string;
  type: string;
  bytes: number;
  data: Blob;
}

export interface PreferenceRecord {
  key: string;
  value: unknown;
  updatedAt: string;
}

export interface SyncOutbox {
  id: string;
  namespaceId: string;
  collection: string;
  objectId: string;
  revision: string;
  envelope: unknown;
  createdAt: string;
}

export class SwitchbackDb extends Dexie {
  routes!: Table<LocalRoute, string>;
  routeRevisions!: Table<RouteRevision, string>;
  blobs!: Table<BlobRecord, string>;
  trackChunks!: Table<TrackChunk, [string, number]>;
  packs!: Table<PackRecord, string>;
  packChunks!: Table<PackChunk, string>;
  preferences!: Table<PreferenceRecord, string>;
  syncOutbox!: Table<SyncOutbox, string>;

  constructor() {
    super("switchback");

    // Preserve every prior schema version in the real repository.
    // This is the target schema example, not permission to delete older migrations.
    this.version(10).stores({
      routes: "id, kind, updatedAt",
      routeRevisions: "id, routeId, contentHash, createdAt",
      blobs: "id, contentHash, kind",
      trackChunks: "[rideId+sequence], rideId, startAt",
      packs: "id, buildId, kind, status",
      packChunks: "hash, packId, type",
      preferences: "key, updatedAt",
      syncOutbox: "id, namespaceId, [collection+objectId], createdAt",
    });
  }
}
