PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;

CREATE TABLE schema_version (
  version INTEGER PRIMARY KEY,
  applied_at TEXT NOT NULL
);

CREATE TABLE road_segment (
  segment_uid TEXT PRIMARY KEY,
  osm_way_id TEXT NOT NULL,
  from_osm_node_id TEXT NOT NULL,
  to_osm_node_id TEXT NOT NULL,
  direction INTEGER NOT NULL,
  source_build_id TEXT NOT NULL,
  geometry_hash TEXT NOT NULL,
  geometry_blob BLOB NOT NULL,
  length_m REAL NOT NULL
);

CREATE INDEX road_segment_way_idx ON road_segment(osm_way_id);

CREATE TABLE road_segment_lineage (
  old_segment_uid TEXT NOT NULL,
  new_segment_uid TEXT NOT NULL,
  overlap_ratio REAL NOT NULL,
  direction_match REAL NOT NULL,
  confidence REAL NOT NULL,
  source_build_id TEXT NOT NULL,
  target_build_id TEXT NOT NULL,
  PRIMARY KEY(old_segment_uid, new_segment_uid, target_build_id)
);

CREATE TABLE road_intrinsic (
  segment_uid TEXT PRIMARY KEY REFERENCES road_segment(segment_uid),
  road_class TEXT,
  surface_json TEXT NOT NULL,
  smoothness TEXT,
  track_type TEXT,
  motorcycle_access TEXT,
  seasonal_access TEXT,
  curvature REAL NOT NULL DEFAULT 0,
  elevation_interest REAL NOT NULL DEFAULT 0,
  scenic_proxy REAL NOT NULL DEFAULT 0,
  flow REAL NOT NULL DEFAULT 0,
  technicality REAL NOT NULL DEFAULT 0,
  mvum_json TEXT,
  access_confidence REAL NOT NULL DEFAULT 0,
  surface_confidence REAL NOT NULL DEFAULT 0,
  source_version TEXT NOT NULL
);

CREATE TABLE rig_route_source (
  route_source_id TEXT PRIMARY KEY,
  artifact_hash TEXT NOT NULL,
  uploader_identity_id TEXT,
  provenance_class TEXT NOT NULL,
  route_fingerprint TEXT NOT NULL,
  duplicate_family_id TEXT NOT NULL,
  source_weight REAL NOT NULL,
  imported_at TEXT NOT NULL
);

CREATE INDEX rig_source_fingerprint_idx ON rig_route_source(route_fingerprint);
CREATE INDEX rig_source_family_idx ON rig_route_source(duplicate_family_id);

CREATE TABLE rig_evidence (
  id TEXT PRIMARY KEY,
  segment_uid TEXT NOT NULL REFERENCES road_segment(segment_uid),
  route_source_id TEXT REFERENCES rig_route_source(route_source_id),
  evidence_kind TEXT NOT NULL,
  route_role TEXT,
  match_confidence REAL,
  covered_fraction REAL,
  positive_weight REAL NOT NULL DEFAULT 0,
  negative_weight REAL NOT NULL DEFAULT 0,
  observed_at TEXT,
  expires_at TEXT,
  payload_json TEXT,
  created_at TEXT NOT NULL
);

CREATE INDEX rig_evidence_segment_idx ON rig_evidence(segment_uid);

CREATE TABLE rig_aggregate (
  segment_uid TEXT PRIMARY KEY REFERENCES road_segment(segment_uid),
  twisty_interest REAL NOT NULL DEFAULT 0,
  gravel_interest REAL NOT NULL DEFAULT 0,
  dirt_interest REAL NOT NULL DEFAULT 0,
  scenic_interest REAL NOT NULL DEFAULT 0,
  elevation_interest REAL NOT NULL DEFAULT 0,
  remoteness REAL NOT NULL DEFAULT 0,
  flow REAL NOT NULL DEFAULT 0,
  technicality REAL NOT NULL DEFAULT 0,
  community_interest REAL NOT NULL DEFAULT 0,
  evidence_confidence REAL NOT NULL DEFAULT 0,
  independent_route_count INTEGER NOT NULL DEFAULT 0,
  independent_identity_count INTEGER NOT NULL DEFAULT 0,
  last_evidence_at TEXT,
  aggregate_version INTEGER NOT NULL
);

CREATE TABLE rig_corridor (
  corridor_id TEXT PRIMARY KEY,
  build_id TEXT NOT NULL,
  entry_segment_uid TEXT NOT NULL,
  exit_segment_uid TEXT NOT NULL,
  segment_ids_json TEXT NOT NULL,
  length_m REAL NOT NULL,
  quality_json TEXT NOT NULL,
  confidence REAL NOT NULL,
  geometry_blob BLOB NOT NULL
);

CREATE TABLE public_identity (
  id TEXT PRIMARY KEY,
  display_name TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  created_at TEXT NOT NULL
);

CREATE TABLE webauthn_credential (
  credential_id TEXT PRIMARY KEY,
  identity_id TEXT NOT NULL REFERENCES public_identity(id),
  public_key BLOB NOT NULL,
  sign_count INTEGER NOT NULL DEFAULT 0,
  transports_json TEXT,
  created_at TEXT NOT NULL,
  last_used_at TEXT
);

CREATE TABLE community_route (
  id TEXT PRIMARY KEY,
  owner_identity_id TEXT NOT NULL REFERENCES public_identity(id),
  visibility TEXT NOT NULL DEFAULT 'public',
  current_revision_id TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active'
);

CREATE TABLE community_route_revision (
  id TEXT PRIMARY KEY,
  route_id TEXT NOT NULL REFERENCES community_route(id),
  parent_revision_id TEXT,
  route_fingerprint TEXT NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  ai_description_json TEXT,
  stats_json TEXT NOT NULL,
  provenance_class TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE community_route_artifact (
  id TEXT PRIMARY KEY,
  revision_id TEXT NOT NULL REFERENCES community_route_revision(id),
  kind TEXT NOT NULL,
  storage_path TEXT NOT NULL,
  sha256 TEXT NOT NULL,
  bytes INTEGER NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE community_comment (
  id TEXT PRIMARY KEY,
  route_id TEXT NOT NULL REFERENCES community_route(id),
  identity_id TEXT NOT NULL REFERENCES public_identity(id),
  body TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'visible',
  created_at TEXT NOT NULL,
  edited_at TEXT
);

CREATE TABLE community_report (
  id TEXT PRIMARY KEY,
  reporter_identity_id TEXT,
  object_type TEXT NOT NULL,
  object_id TEXT NOT NULL,
  reason TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open',
  created_at TEXT NOT NULL
);

CREATE TABLE moderation_audit (
  id TEXT PRIMARY KEY,
  actor_identity_id TEXT,
  action TEXT NOT NULL,
  object_type TEXT NOT NULL,
  object_id TEXT NOT NULL,
  payload_json TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE sync_namespace (
  id TEXT PRIMARY KEY,
  owner_identity_id TEXT REFERENCES public_identity(id),
  created_at TEXT NOT NULL
);

CREATE TABLE sync_object (
  namespace_id TEXT NOT NULL REFERENCES sync_namespace(id),
  collection TEXT NOT NULL,
  object_id TEXT NOT NULL,
  revision TEXT NOT NULL,
  nonce BLOB NOT NULL,
  ciphertext BLOB NOT NULL,
  tombstone INTEGER NOT NULL DEFAULT 0,
  byte_count INTEGER NOT NULL,
  updated_at TEXT NOT NULL,
  PRIMARY KEY(namespace_id, collection, object_id, revision)
);

CREATE TABLE pack_release (
  pack_id TEXT NOT NULL,
  build_id TEXT NOT NULL,
  manifest_json TEXT NOT NULL,
  status TEXT NOT NULL,
  created_at TEXT NOT NULL,
  PRIMARY KEY(pack_id, build_id)
);
