# Product Contract

## User promise

Switchback should let a rider open the app and immediately do one of four things:

### Where to?
"Take me to a destination, but choose roads I will enjoy."

Always include a direct/fast baseline and clearly show the cost of the recreational route.

### Make a Loop
"I have 2 hours. Give me a ride and bring me back."

Time/distance constraints are planning constraints, not decorative labels.

### Just Ride
"I have no destination."

Switchback should be mostly quiet and occasionally surface a genuinely worthwhile road or mini-loop that is reachable ahead.

### Import GPX
"Someone sent me a GPX."

Switchback should:
- understand the file,
- map-match what can be matched,
- retain unmatched track-only spans,
- analyze route character,
- get the rider to a sensible entry point,
- continue through the GPX without an artificial "arrived at the start" stop,
- export back to other ecosystems.

## Audience

Primary:
- ADV
- dual sport
- gravel/backroad recreational riding

Secondary:
- touring/cruiser/street riders who prefer scenic/curvy pavement

## Bike-driven defaults

### Dual Sport
- gravel strongly preferred
- dirt allowed
- rough technical trail based on explicit rider tolerance
- highway strongly penalized

### ADV
- gravel preferred
- dirt allowed
- moderate technical terrain configurable
- highway penalized

### Touring
- paved preferred
- gravel avoided by default
- scenic/curvy rewarded
- highway acceptable when needed

### Custom
User-owned policy.

## Normal rider-visible ride intents

- Mixed
- Gravel Hunt
- Twisties
- Scenic
- Fast Backroads

These are **weight presets**, not independent routing engines.

## Non-goals for v1

- social feed
- follower system
- direct messages
- clubs/forums
- native CarPlay/Android Auto
- subscriptions
- public live rider tracking
- nationwide preloaded graph
- generic "AI chat" occupying the product
