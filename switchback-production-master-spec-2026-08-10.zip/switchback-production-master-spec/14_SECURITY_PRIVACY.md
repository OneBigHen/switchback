# Security and Privacy

## Threats

- public GraphHopper exposure
- provider key leak
- GPX/XML parser abuse
- XXE
- giant file / decompression bomb
- path traversal
- stored XSS/comments
- prompt injection from community text
- WebAuthn replay/session mistakes
- CSRF
- sync ciphertext metadata leakage
- public home coordinate leakage
- rate abuse
- malicious offline pack
- compromised region builder artifact
- admin/moderation misuse

## Network

Public:
- Caddy/edge
- Next.js web/API

Private:
- GraphHopper
- Valhalla
- worker admin endpoints
- SQLite
- artifact storage

## Upload

- strict max bytes
- streaming XML
- external entities disabled
- max point count
- bounded CPU/time
- generated storage names
- content hash
- no trust in MIME/filename
- original outside web root

## Web

- CSP
- HSTS
- Referrer-Policy
- X-Content-Type-Options
- Permissions-Policy
- secure HttpOnly SameSite cookies
- CSRF on authenticated mutations
- rate limiting
- strict runtime schemas

## Location privacy

Default:
- raw ride trace local
- exact coordinates not retained in server logs
- route logs use coarse region/request id
- public upload has redaction preview

## Prompt injection

Community note/comment is untrusted data.

AI prompt:
- system rules fixed
- community content passed as quoted/data field
- no tool instruction accepted from it

## Pack security

Manifest:
- HTTPS
- SHA-256 hashes
- schema version
- build id
- size
- required app version

Optional future:
- signed manifests with instance signing key

Corrupt chunk is rejected before activation.

## Backup

Irreplaceable:
- community DB
- route artifacts
- RIG evidence
- sync opaque objects
- configuration/secrets separately

Rebuildable:
- GraphHopper cache/graph
- region derived tiles

Restore drill mandatory.
