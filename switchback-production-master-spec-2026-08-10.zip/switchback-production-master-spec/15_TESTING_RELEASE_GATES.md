# Testing and Release Gates

## Test classes

### Unit
- eligibility matrices
- scoring
- dedupe
- canonical segment migration
- RIG evidence
- Free Ride state
- GPX parser
- export
- sync envelopes
- pack manifests

### Property tests
- score boundedness
- route similarity symmetry
- evidence duplicate saturation
- pack manifest round trip
- simplification preserves protected anchors
- migration idempotence

### Fuzz
- GPX XML
- route intent JSON
- pack manifest
- community comment sanitizer
- sync envelope parser

### Integration
- real GraphHopper
- worker ingest
- RIG query
- WebAuthn
- region install
- encrypted sync

### E2E
- critical rider journeys
- offline
- PWA updates
- community

### Simulation
- GPS jitter
- heading reversal
- Free Ride 60–120 min
- route deviations
- offline pack boundary

### Soak
- memory
- repeated planning
- 4-hour nav
- 50 reroutes

### Field
- real iPhone
- mounted portrait/landscape
- weak/no signal
- GPX join
- Free Ride
- battery/thermal

## Golden route corpus

Required local corpus:
- Hatboro → New Hope/Stockton
- Hatboro loop
- Hatboro → Jim Thorpe
- PA forest/gravel
- known boring connector
- known excellent gravel
- known excellent paved twisty
- explicit forbidden/private example
- seasonal official example
- ambiguous surface example
- cross PA/NJ

Assertions are relational:
- route A ranks above route B
- contains/avoids corridor
- surface confidence within expected bounds
not brittle exact polyline unless regression fixture.

## Chaos

Inject:
- GraphHopper timeout
- router restart
- AI outage
- Places quota
- corrupted IndexedDB entry
- pack chunk missing
- service worker update mid-ride
- storage quota failure
- worker crash
- GPS denied
- GPS poor accuracy
- internet loss

## Private beta gate

After P29:
- all core tests green
- field 5 rides
- two weak/no signal
- one 2+ hr
- Free Ride
- GPX join
- memory plateau

## Community release gate

After P36:
- 3 external riders
- no developer assistance to complete a ride
- publish/privacy workflow proven
- moderation/report path proven
- no Sev-1/2
