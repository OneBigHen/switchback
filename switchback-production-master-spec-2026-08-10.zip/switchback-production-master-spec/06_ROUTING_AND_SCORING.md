# Routing, Candidate Generation, and Scoring

## Pipeline

```text
Ride intent
  ↓
Hard constraints
  ↓
Feasible search area
  ↓
Candidate generation
  ↓
Router legality/topology
  ↓
Feature extraction
  ↓
Eligibility
  ↓
Utility
  ↓
Diversity
  ↓
Explanation
```

## Candidate sources

A-to-B:
1. fastest/direct baseline
2. GraphHopper native alternatives
3. RIG corridor anchors
4. gravel/ADV corridor anchors
5. scenic/elevation corridor anchors
6. community route corridor overlays
7. explicit Must/Prefer road constraints

Loop:
1. router round-trip seeds
2. heading-sector anchors
3. target-radius rings
4. high-value RIG clusters
5. road-character corridor chains

Do not generate random waypoint soup.

## Feasible A-to-B envelope

Given direct time `T0` and max detour ratio `d`:
- candidate corridor must be reachable within `(1+d)*T0`
- use graph-based or conservative geometric prefilter
- final feasibility is always router-confirmed

## Anchor search

Treat corridor selection as a bounded orienteering approximation.

State:

```text
(last_anchor,
 elapsed_cost,
 reward,
 visited_corridors,
 heading,
 surface_mix)
```

Candidate reward:

```text
anchor_reward =
corridor_quality
* useful_length
* confidence
* intent_fit
* novelty
```

Beam:

```text
beam_value =
reward
- λ_time * detour
- λ_repeat * overlap
- λ_uncertain * uncertainty
- λ_fragment * fragmentation
```

Initial beam width is a benchmark parameter, not a product constant.

## Eligibility

Hard reject before utility when:
- motorcycle access forbidden
- active applicable closure
- incompatible hard surface policy
- hard avoid/must constraint violated
- topology invalid
- hard duration/distance maximum violated
- offline-only request leaves installed graph coverage
- pathological self-overlap beyond explicit allowed threshold

Unknown surface/access should generally produce uncertainty, not invented rejection.

## Utility

For route `r`:

```text
segment_utility =
  w_gravel * gravel
+ w_dirt * dirt
+ w_twisty * curvature
+ w_scenic * scenic
+ w_elev * elevation
+ w_flow * flow
+ w_rig * community_interest
+ w_novel * novelty
- w_highway * highway
- w_urban * urban_stop
- w_uncertain * uncertainty

route_utility =
length_weighted(segment_utility)
+ contiguous_quality_bonus
+ corridor_coherence_bonus
+ personal_preference_fit
- backtrack_penalty
- self_overlap_penalty
- fragmentation_penalty
- detour_penalty
```

## Contiguous quality bonus

For every contiguous run above a minimum quality threshold:

```text
bonus(run) =
mean_quality
* log1p(run_length_km)
* coherence
```

This creates diminishing returns while correctly preferring a sustained good road.

## Time penalty

Do not penalize every extra minute equally.

For recreational intent:
- small detour inside requested budget has tiny penalty
- after preferred duration band, penalty ramps sharply
- hard maximum rejects

Use piecewise or smooth hinge loss.

## Surface probability

A segment can have:

```text
P(paved)
P(gravel)
P(dirt)
P(rough)
P(unknown)
```

Route surface mix propagates probability weighted by length.

Do not convert uncertainty into fake certainty just to show a pie chart.

## Diversity

Compute similarity using canonical directed segment length, not polyline pixels.

```text
overlap(a,b) =
shared_segment_length / min(length_a, length_b)
```

Weighted Jaccard is also recorded.

Select via MMR:

```text
MMR(route) =
normalized_utility
- diversity_lambda * max_similarity_to_selected
```

Normal output target:
- 3 candidates maximum
- each materially different
- duplicate threshold calibrated on golden corpus

## Explanations

Normal UI should expose facts:

- `31 mi mapped gravel/unpaved`
- `+18 min vs fastest`
- `uses 3 high-confidence community corridors`
- `avoids 21 mi of highway`
- `6% surface unknown`
- `MVUM designated on 14 mi`

Do not show a magic 87/100 unless user opts into diagnostics.

## Personal learning

V1 is transparent signed preference adaptation, not neural ML.

Signals:
- route selected over alternatives → weak positive preference
- accepted Free Ride → positive
- more-like-this → strong positive
- ignored Free Ride → near-neutral
- less-like-this → explicit negative
- abandoned ride → ambiguous, no automatic negative

Separate per stable bike id.

Never allow personalization to override legality/access.
