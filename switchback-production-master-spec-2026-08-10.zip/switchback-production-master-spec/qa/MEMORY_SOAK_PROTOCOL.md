# Browser Memory Soak Protocol

## Scenario A — Planner cycle
Repeat 10x:
- Explore
- search Hatboro → Stockton
- plan
- switch all alternatives
- customize
- edit
- undo/redo
- clear
- return Explore

Check:
- heap stabilized
- source count
- layer count
- listeners
- route cache count
- worker tiles/bytes

Gate:
settled heap ≤ stabilized baseline +20%.

## Scenario B — Reroute
- start ride fixture
- simulate movement
- trigger 50 controlled deviations/rejoins
- complete ride

Gate:
- no retained 50 route generations
- no increasing source ids
- no extra location watches

## Scenario C — 4-hour ride
- playback realistic GPS at 1 Hz
- voice events
- Free Ride candidate ticks
- offline tile loading

Gate:
- plateau after warmup
- bounded GPS buffer
- no UI long-task degradation
