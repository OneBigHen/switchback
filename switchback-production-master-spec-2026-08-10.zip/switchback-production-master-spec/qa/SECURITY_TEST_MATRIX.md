# Security Test Matrix

- XXE payload rejected
- billion-laughs / entity expansion rejected
- oversized GPX rejected
- huge point-count bounded
- filename path traversal ignored
- HTML/script in comment rendered inert
- AI prompt-injection note treated as data
- CSRF on publish rejected
- expired WebAuthn challenge rejected
- replayed assertion/session rejected per ceremony/session rules
- unauthenticated sync denied
- sync server fixture never sees plaintext route name/geometry
- privacy trim removes geometry + instruction metadata
- rate limit route/upload/comment endpoints
- public GraphHopper port unreachable externally
- provider keys absent from client JS
- CSP tests for MapLibre worker configuration
