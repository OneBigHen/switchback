# Physical Field Test

For each ride record:
- app build
- graph/RIG build
- device/iOS
- battery start/end
- brightness
- cellular state
- installed pack
- route/free ride mode
- incidents

Required private-beta rides:
1. Hatboro local 45–60 min
2. New Hope/Stockton route
3. 2+ hour ADV/backroad ride
4. weak signal / airplane-mode controlled route
5. Free Ride no-destination session
6. GPX Best Join session

Test:
- portrait
- landscape
- screen lock/background behavior
- audio/music coexistence
- voice
- thermal
- reroute
- intentional deviation
