# Chaos Matrix

| Failure | Expected result |
|---|---|
| GraphHopper timeout | route error, current route preserved |
| GraphHopper restart mid-plan | request fails cleanly; retry works |
| AI unavailable | deterministic parser/core app works |
| Google Places quota | Photon/map pick remains |
| Geo Worker crash | controlled restart; ride state not falsely advanced |
| IO Worker crash during GPX | job fails; original file remains |
| Storage quota | pack install aborts; active pack untouched |
| Corrupt pack chunk | hash failure; not activated |
| Internet loss mid-ride | installed capability continues |
| Leave pack coverage | explicit degraded warning |
| Service worker update | deferred in Ride |
| GPS poor accuracy | guidance uncertain; no aggressive reroute |
| GPS denied | preview/manual route possible |
| DB migration error | recoverable/backup path; no silent wipe |
