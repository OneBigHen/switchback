# Critical E2E Journeys

1. current location → destination → candidates → start ride
2. 2-hour loop → candidates → start ride
3. free-text ADV request
4. location denied → map-select start
5. GraphHopper unavailable
6. search provider unavailable → fallback
7. import GPX → analyze
8. import GPX → Best Join → approach → GPX → finish
9. unmatched GPX track span
10. export generic Track
11. Just Ride start
12. Free Ride accepts road
13. Free Ride ignores twice → quiet
14. offline Ride Pack cold launch
15. offline reroute
16. missing offline region
17. pack update interrupted
18. service worker update while riding
19. anonymous community browse
20. passkey identity registration
21. publish with privacy trim
22. comment/report
23. encrypted sync push/pull
24. edit Must/Prefer/Avoid road
25. Explorer Mode lazy layer on/off
